-- ============================================================================
-- Dragon Store: FIX + UPGRADE (jalankan SEKALI di Supabase SQL Editor)
-- ============================================================================
-- File ini AMAN dijalankan berkali-kali (idempotent). Isinya:
--   1) Perbaikan total fitur komentar (RLS, grant akses, refresh schema cache)
--   2) Sistem role: owner / seller / member
--   3) Fitur Seller: owner bisa angkat member jadi seller, seller cuma bisa
--      kelola produknya sendiri (dijamin di level database, bukan cuma UI)
--   4) Pengetatan keamanan: kategori, hapus komentar, dan notifikasi broadcast
--      yang sebelumnya bisa diakses sembarang user lewat API langsung
--   5) Format Public ID baru: "0~~~1", "0~~~2", dst (client~~~urutan akun)
--
-- Jalankan ini SETELAH schema.sql (kalau belum pernah dijalankan sama sekali,
-- jalankan schema.sql dulu, baru file ini).
-- ============================================================================

-- ============================================================================
-- BAGIAN 1 — ROLE SYSTEM (owner / seller / member)
-- ============================================================================

alter table public.profiles
  add column if not exists role text not null default 'member';

alter table public.profiles
  add column if not exists verified boolean not null default false;

alter table public.profiles
  drop constraint if exists profiles_role_check;
alter table public.profiles
  add constraint profiles_role_check check (role in ('owner', 'seller', 'member'));

-- Pastikan akun owner (berdasarkan email di OWNER_EMAIL pada src/db.js) selalu
-- berstatus 'owner' + verified=true, siapa pun yang sebelumnya terdaftar dengan email itu.
update public.profiles set role = 'owner' where email = 'iputu.aditya789@gmail.com' and role <> 'owner';
update public.profiles set verified = true where email = 'iputu.aditya789@gmail.com' and verified <> true;

-- Fungsi bantu: role user yang sedang login. stable + tanpa security definer
-- karena tabel profiles sudah bisa dibaca semua orang (policy select using true).
create or replace function public.current_role()
returns text language sql stable as $$
  select role from public.profiles where id = auth.uid();
$$;

create or replace function public.is_owner()
returns boolean language sql stable as $$
  select coalesce((select role = 'owner' from public.profiles where id = auth.uid()), false);
$$;

-- Update trigger handle_new_user supaya akun baru otomatis kebagian role yang
-- benar (owner kalau emailnya cocok, member kalau bukan).
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, username, email, public_id, role, verified)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)),
    new.email,
    public.generate_public_id(),
    case when new.email = 'iputu.aditya789@gmail.com' then 'owner' else 'member' end,
    new.email = 'iputu.aditya789@gmail.com'
  );
  return new;
end;
$$;

-- RPC: owner mengangkat member jadi seller / mencabutnya kembali jadi member.
-- security definer supaya bisa update kolom 'role' milik user lain (RLS normal
-- profiles cuma izinkan auth.uid() = id untuk update), tapi di dalam fungsi ini
-- kita verifikasi manual bahwa pemanggilnya memang owner, jadi tetap aman.
create or replace function public.set_seller_status(target_public_id text, make_seller boolean)
returns void language plpgsql security definer as $$
begin
  if not public.is_owner() then
    raise exception 'Hanya owner yang bisa mengubah status seller.';
  end if;
  update public.profiles
  set role = case when make_seller then 'seller' else 'member' end
  where public_id = target_public_id
    and role <> 'owner'; -- jaga-jaga: owner tidak bisa di-demote lewat jalur ini
end;
$$;

-- RPC: owner memberi/mencabut centang biru SIAPA PUN, independen dari role
-- (seller belum tentu verified; member biasa pun bisa diberi centang biru
-- kalau owner mau). Owner sendiri selalu verified otomatis, tidak bisa diubah
-- lewat jalur ini.
create or replace function public.set_verified_status(target_public_id text, make_verified boolean)
returns void language plpgsql security definer as $$
begin
  if not public.is_owner() then
    raise exception 'Hanya owner yang bisa mengubah status centang biru.';
  end if;
  update public.profiles
  set verified = make_verified
  where public_id = target_public_id
    and role <> 'owner';
end;
$$;

grant execute on function public.current_role() to anon, authenticated;
grant execute on function public.is_owner() to anon, authenticated;
grant execute on function public.set_seller_status(text, boolean) to authenticated;
grant execute on function public.set_verified_status(text, boolean) to authenticated;

-- ============================================================================
-- BAGIAN 2 — FORMAT PUBLIC ID BARU: "00000001", "00000002", dst
-- ============================================================================
-- Format 8 digit zero-padded. User pertama = 00000001, user ke-100 = 00000100.
-- Otomatis lanjut dari urutan yang sudah ada (profile_seq).
create or replace function public.generate_public_id()
returns text language sql as $$
  select lpad(nextval('public.profile_seq')::text, 8, '0');
$$;
-- Catatan: ini hanya berlaku untuk akun BARU yang daftar setelah file ini
-- dijalankan. Akun lama tetap memakai ID format lama supaya
-- link profil yang sudah dibagikan tidak rusak.

-- ============================================================================
-- BAGIAN 3 — PRODUK: kolom seller_id + kebijakan akses per-role
-- ============================================================================

alter table public.products
  add column if not exists seller_id uuid references public.profiles(id) on delete set null;
-- seller_id NULL = produk milik toko/owner. Terisi = produk milik seller tsb.

create index if not exists idx_products_seller_id on public.products(seller_id);

-- Buang policy lama yang kelewat longgar (mengizinkan SEMBARANG user yang
-- login untuk insert/update/delete produk APAPUN lewat API langsung).
drop policy if exists "Authenticated users can manage products" on public.products;

-- Owner: bebas kelola semua produk.
drop policy if exists "Owner manages all products" on public.products;
create policy "Owner manages all products" on public.products
  for all using (public.is_owner()) with check (public.is_owner());

-- Seller: hanya boleh kelola (insert/update/delete) produk miliknya sendiri,
-- dan saat insert wajib mengisi seller_id = dirinya sendiri (tidak bisa
-- mengaku-aku jadi seller lain atau membuat produk atas nama toko/owner).
drop policy if exists "Sellers manage own products" on public.products;
create policy "Sellers manage own products" on public.products
  for all using (public.current_role() = 'seller' and seller_id = auth.uid())
  with check (public.current_role() = 'seller' and seller_id = auth.uid());

-- (Policy "Products are viewable by everyone" dari schema.sql tetap berlaku,
-- jadi semua orang—termasuk pengunjung yang belum login—tetap bisa lihat
-- semua produk seperti biasa.)

-- ============================================================================
-- BAGIAN 4 — PENGETATAN KEAMANAN TAMBAHAN
-- ============================================================================

-- Kategori: sebelumnya SEMBARANG user yang login bisa tambah/hapus kategori
-- lewat API langsung. Sekarang dibatasi ke owner saja (seller cukup MEMILIH
-- dari kategori yang ada, tidak perlu bisa menambah kategori baru).
drop policy if exists "Authenticated users can manage categories" on public.categories;
drop policy if exists "Owner manages categories" on public.categories;
create policy "Owner manages categories" on public.categories
  for all using (public.is_owner()) with check (public.is_owner());

-- Komentar: sebelumnya SEMBARANG user yang login bisa hapus komentar SIAPA
-- PUN lewat API langsung (UI cuma menyembunyikan tombolnya untuk non-owner).
-- Sekarang: owner boleh hapus komentar siapa saja, seller boleh hapus komentar
-- SIAPA PUN di produk miliknya sendiri, user lain hanya boleh hapus komentar
-- miliknya sendiri.
drop policy if exists "Authenticated users can delete comments" on public.comments;
drop policy if exists "Owner or author can delete comments" on public.comments;
drop policy if exists "Owner, author, or product seller can delete comments" on public.comments;
create policy "Owner, author, or product seller can delete comments" on public.comments
  for delete using (
    public.is_owner()
    or auth.uid() = user_id
    or exists (select 1 from public.products p where p.id = comments.product_id and p.seller_id = auth.uid())
  );

-- Notifikasi: sebelumnya SEMBARANG user yang login bisa mengirim notifikasi
-- bertipe apa pun ke siapa pun, termasuk berpura-pura jadi "broadcast resmi
-- dari owner" (admin-broadcast) atau "produk baru" (new-product). Sekarang
-- dua tipe itu dikunci untuk owner saja; tipe lain (comment, comment-like,
-- profile-like — notifikasi antar-user biasa) tetap bebas seperti semula.
drop policy if exists "Authenticated users can create notifications" on public.notifications;
drop policy if exists "Users send notifications, owner-only broadcast types" on public.notifications;
create policy "Users send notifications, owner-only broadcast types" on public.notifications
  for insert with check (
    auth.role() = 'authenticated'
    and (type not in ('admin-broadcast', 'new-product') or public.is_owner())
  );

-- ============================================================================
-- BAGIAN 5 — FIX TOTAL FITUR KOMENTAR
-- ============================================================================
-- Kalau komentar sebelumnya gagal terkirim, kemungkinan besar karena salah
-- satu dari: policy RLS belum lengkap, grant tabel belum lengkap, atau cache
-- schema PostgREST belum di-refresh setelah tabel dibuat. Semua ditangani di
-- bawah ini secara aman (DROP IF EXISTS lalu CREATE ulang).

-- Pastikan tabel ada (no-op kalau sudah ada dari schema.sql).
create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  product_id text references public.products(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  text text not null,
  created_at timestamptz default now()
);

create table if not exists public.comment_likes (
  comment_id uuid references public.comments(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (comment_id, user_id)
);

alter table public.comments enable row level security;
alter table public.comment_likes enable row level security;

drop policy if exists "Comments are viewable by everyone" on public.comments;
create policy "Comments are viewable by everyone" on public.comments for select using (true);

drop policy if exists "Users can post own comments" on public.comments;
create policy "Users can post own comments" on public.comments for insert with check (auth.uid() = user_id);

drop policy if exists "Comment likes are viewable by everyone" on public.comment_likes;
create policy "Comment likes are viewable by everyone" on public.comment_likes for select using (true);

drop policy if exists "Users can like comments" on public.comment_likes;
create policy "Users can like comments" on public.comment_likes for insert with check (auth.uid() = user_id);

drop policy if exists "Users can unlike own comment likes" on public.comment_likes;
create policy "Users can unlike own comment likes" on public.comment_likes for delete using (auth.uid() = user_id);

-- Grant level tabel (terpisah dari RLS). Supabase biasanya sudah otomatis
-- memberi ini ke anon/authenticated, tapi kita pastikan ulang secara
-- eksplisit supaya tidak ada kemungkinan tabel ini "terlewat".
grant select on public.comments to anon, authenticated;
grant insert, delete on public.comments to authenticated;
grant select on public.comment_likes to anon, authenticated;
grant insert, delete on public.comment_likes to authenticated;
grant usage on schema public to anon, authenticated;

-- Minta PostgREST reload schema cache-nya. Tanpa ini, kadang tabel/kolom yang
-- baru dibuat lewat SQL Editor tidak langsung "terlihat" oleh API sampai
-- project di-restart manual.
notify pgrst, 'reload schema';

-- ============================================================================
-- BAGIAN 6 — Grant tambahan untuk fungsi-fungsi RPC ban/unban (jaga-jaga kalau
-- belum ke-grant di proyek lama)
-- ============================================================================
grant execute on function public.delete_my_account_if_ban_expired() to authenticated;
grant execute on function public.ban_user(text, numeric, text) to authenticated;
grant execute on function public.unban_user(text) to authenticated;

-- ============================================================================
-- BAGIAN 7 — FITUR TEMAN: cari teman, jumlah teman publik, daftar teman privat
-- ============================================================================
-- Model satu-arah sederhana: kalau A menambahkan B, artinya A menganggap B
-- teman. Jumlah teman ditampilkan publik (lewat RPC get_friend_count), tapi
-- DAFTAR siapa-siapa-nya tetap privat — RLS select hanya mengizinkan kamu
-- melihat baris milikmu sendiri.
create table if not exists public.friends (
  user_id uuid references public.profiles(id) on delete cascade,
  friend_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (user_id, friend_id)
);

alter table public.friends drop constraint if exists friends_no_self;
alter table public.friends add constraint friends_no_self check (user_id <> friend_id);

create index if not exists idx_friends_friend_id on public.friends(friend_id);

alter table public.friends enable row level security;
drop policy if exists "Users see own friend list" on public.friends;
create policy "Users see own friend list" on public.friends for select using (auth.uid() = user_id);
drop policy if exists "Users add own friends" on public.friends;
create policy "Users add own friends" on public.friends for insert with check (auth.uid() = user_id);
drop policy if exists "Users remove own friends" on public.friends;
create policy "Users remove own friends" on public.friends for delete using (auth.uid() = user_id);
grant select, insert, delete on public.friends to authenticated;

-- RPC publik: hanya mengembalikan ANGKA jumlah teman, tanpa membuka daftarnya.
create or replace function public.get_friend_count(target_user_id uuid)
returns bigint language sql stable security definer as $$
  select count(*) from public.friends where user_id = target_user_id;
$$;

-- RPC: saat seseorang like sebuah produk, beri notifikasi ke semua orang yang
-- menjadikan dia teman. Wajib security definer karena pelaku sendiri TIDAK
-- diizinkan RLS untuk tahu siapa saja yang menjadikan dia teman (privasi).
create or replace function public.notify_friends_of_product_like(p_liker_id uuid, p_product_id text, p_product_name text)
returns void language plpgsql security definer as $$
declare
  liker_username text;
begin
  if p_liker_id <> auth.uid() then
    raise exception 'Tidak diizinkan.';
  end if;
  select username into liker_username from public.profiles where id = p_liker_id;
  if liker_username is null then return; end if;
  insert into public.notifications (user_id, type, message, link)
  select f.user_id, 'friend-like-product',
         liker_username || ' menyukai produk "' || p_product_name || '". Yuk lihat juga! 👀',
         '/produk/' || p_product_id
  from public.friends f
  where f.friend_id = p_liker_id;
end;
$$;

grant execute on function public.get_friend_count(uuid) to anon, authenticated;
grant execute on function public.notify_friends_of_product_like(uuid, text, text) to authenticated;

-- ============================================================================
-- SELESAI. Cek hasilnya:
-- ============================================================================
select 'OK - role column' as check_name, count(*) as total from public.profiles;
select 'OK - products with seller_id column' as check_name, count(*) as total from public.products;
select 'OK - friends table' as check_name, count(*) as total from public.friends;
-- Kalau tiga query di atas jalan tanpa error, migrasi berhasil.
-- ============================================================================
