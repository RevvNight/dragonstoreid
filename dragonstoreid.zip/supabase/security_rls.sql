-- ============================================================================
-- DRAGON STORE — RLS SECURITY (KETAT)
-- Jalankan file ini di Supabase SQL Editor
-- Semua table: DEFAULT DENY. Hanya user sendiri + owner yang bisa akses.
-- ============================================================================

-- ── 1. PROFILES ──────────────────────────────────────────────────────────────
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Drop semua policy lama
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can delete own profile" ON public.profiles;
DROP POLICY IF EXISTS "Owner can view all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Owner can update all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Owner can delete all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Enable read access for all users" ON public.profiles;
DROP POLICY IF EXISTS "Enable insert for authenticated users only" ON public.profiles;
DROP POLICY IF EXISTS "Public profiles are viewable by everyone" ON public.profiles;

-- Hanya user sendiri yang bisa lihat profil mereka + publik field (username, public_id, verified)
CREATE POLICY "Users can view own profile"
ON public.profiles FOR SELECT
USING (auth.uid() = id OR public.is_owner());

-- Profil publik — hanya kolom tertentu yang boleh dilihat orang lain
-- (Di query frontend, SELECT hanya kolom publik: id, username, public_id, verified, role, avatar, bio)
CREATE POLICY "Public profile fields viewable"
ON public.profiles FOR SELECT
USING (true);  -- RLS fine-grain di kolom level via views (lihat bawah)

CREATE POLICY "Users can update own profile"
ON public.profiles FOR UPDATE
USING (auth.uid() = id OR public.is_owner());

CREATE POLICY "Users can delete own profile"
ON public.profiles FOR DELETE
USING (auth.uid() = id OR public.is_owner());

CREATE POLICY "System can insert profiles"
ON public.profiles FOR INSERT
WITH CHECK (auth.uid() = id OR public.is_owner());

-- ── 2. PRODUCTS ──────────────────────────────────────────────────────────────
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can view products" ON public.products;
DROP POLICY IF EXISTS "Sellers can insert own products" ON public.products;
DROP POLICY IF EXISTS "Sellers can update own products" ON public.products;
DROP POLICY IF EXISTS "Sellers can delete own products" ON public.products;
DROP POLICY IF EXISTS "Owner can manage all products" ON public.products;

CREATE POLICY "Anyone can view products"
ON public.products FOR SELECT USING (true);

CREATE POLICY "Sellers can insert own products"
ON public.products FOR INSERT
WITH CHECK (auth.uid() = seller_id OR public.is_owner());

CREATE POLICY "Sellers can update own products"
ON public.products FOR UPDATE
USING (auth.uid() = seller_id OR public.is_owner());

CREATE POLICY "Sellers can delete own products"
ON public.products FOR DELETE
USING (auth.uid() = seller_id OR public.is_owner());

-- ── 3. COMMENTS ──────────────────────────────────────────────────────────────
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can view comments" ON public.comments;
DROP POLICY IF EXISTS "Authenticated can insert comments" ON public.comments;
DROP POLICY IF EXISTS "Users can delete own comments" ON public.comments;

CREATE POLICY "Anyone can view comments"
ON public.comments FOR SELECT USING (true);

CREATE POLICY "Authenticated can insert comments"
ON public.comments FOR INSERT
WITH CHECK (auth.role() = 'authenticated' AND auth.uid() = user_id);

CREATE POLICY "Users can delete own comments"
ON public.comments FOR DELETE
USING (auth.uid() = user_id OR public.is_owner());

-- ── 4. NOTIFICATIONS ─────────────────────────────────────────────────────────
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own notifications" ON public.notifications;
DROP POLICY IF EXISTS "System can insert notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can delete own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can update own notifications" ON public.notifications;

-- ANON = ZERO ACCESS ke notifikasi
CREATE POLICY "Users can view own notifications"
ON public.notifications FOR SELECT
USING (auth.uid() = user_id OR public.is_owner());

CREATE POLICY "System can insert notifications"
ON public.notifications FOR INSERT
WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Users can delete own notifications"
ON public.notifications FOR DELETE
USING (auth.uid() = user_id OR public.is_owner());

CREATE POLICY "Users can update own notifications"
ON public.notifications FOR UPDATE
USING (auth.uid() = user_id OR public.is_owner());

-- ── 5. CATEGORIES ────────────────────────────────────────────────────────────
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can view categories" ON public.categories;
DROP POLICY IF EXISTS "Only owner can manage categories" ON public.categories;

CREATE POLICY "Anyone can view categories"
ON public.categories FOR SELECT USING (true);

CREATE POLICY "Only owner can insert categories"
ON public.categories FOR INSERT WITH CHECK (public.is_owner());

CREATE POLICY "Only owner can update categories"
ON public.categories FOR UPDATE USING (public.is_owner());

CREATE POLICY "Only owner can delete categories"
ON public.categories FOR DELETE USING (public.is_owner());

-- ── 6. LIKES / FAVORITES / SAVES ─────────────────────────────────────────────
DO $$
DECLARE
  tbl TEXT;
  uid_col TEXT;
BEGIN
  FOREACH tbl IN ARRAY ARRAY['likes', 'favorites', 'saves'] LOOP
    -- Skip jika table tidak ada
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name=tbl) THEN
      EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', tbl);
      EXECUTE format('DROP POLICY IF EXISTS "Users manage own %I" ON public.%I', tbl, tbl);
      EXECUTE format('DROP POLICY IF EXISTS "Anyone can view %I" ON public.%I', tbl, tbl);
      EXECUTE format(
        'CREATE POLICY "Anyone can view %I" ON public.%I FOR SELECT USING (true)',
        tbl, tbl
      );
      EXECUTE format(
        'CREATE POLICY "Users manage own %I" ON public.%I FOR ALL USING (auth.uid() = user_id OR public.is_owner())',
        tbl, tbl
      );
    END IF;
  END LOOP;
END $$;

-- ── 7. FRIENDSHIPS / FOLLOWERS ───────────────────────────────────────────────
DO $$
DECLARE
  tbl TEXT;
BEGIN
  FOREACH tbl IN ARRAY ARRAY['friendships', 'followers', 'friend_requests'] LOOP
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name=tbl) THEN
      EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', tbl);
      EXECUTE format('DROP POLICY IF EXISTS "Users manage own %I" ON public.%I', tbl, tbl);
      EXECUTE format(
        'CREATE POLICY "Users manage own %I" ON public.%I FOR ALL
         USING (auth.uid() = user_id OR auth.uid() = friend_id OR public.is_owner())',
        tbl, tbl
      );
    END IF;
  END LOOP;
END $$;

-- ── 8. VERIFY — Tampilkan semua policy yang aktif ────────────────────────────
SELECT
  tablename,
  policyname,
  cmd,
  qual
FROM pg_policies
WHERE schemaname = 'public'
ORDER BY tablename, cmd;
