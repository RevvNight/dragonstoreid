-- ============================================================================
-- Dragon Store: Hapus Semua Akun Lama (sekali jalan, sebelum go-live)
-- ============================================================================
-- Jalankan ini di Supabase Dashboard → SQL Editor, SETELAH schema.sql sudah
-- dijalankan. Tujuannya: bersihkan akun-akun testing biar tidak numpuk
-- dengan akun member yang baru daftar nanti.
--
-- ⚠️ PERINGATAN: Ini menghapus SEMUA akun secara PERMANEN, termasuk milik
-- owner. Kalau akun owner ikut terhapus, daftar ulang pakai email owner yang
-- sama setelah ini — sistem akan otomatis mengenalinya sebagai owner lagi
-- (karena pengecekan owner berdasarkan alamat email, bukan ID).
--
-- Like, favorit, simpan, komentar, dan notifikasi akan ikut terhapus otomatis
-- (cascade) karena semuanya terhubung ke akun yang dihapus. Produk TIDAK
-- ikut terhapus — aman.
-- ============================================================================

delete from auth.users;

-- Setelah ini selesai jalan tanpa error, semua akun lama sudah bersih.
-- Cek hasilnya:
select count(*) as sisa_akun from public.profiles;
-- Harus menunjukkan 0.
