-- ============================================================================
-- Dragon Store: Supabase Schema
-- Jalankan seluruh file ini di Supabase Dashboard → SQL Editor → New query
-- ============================================================================

-- ── Users ────────────────────────────────────────────────────────────────────
-- Kita pakai tabel profiles terpisah dari auth.users (bawaan Supabase Auth),
-- supaya bisa simpan username, public_id, dst tanpa menyentuh tabel auth internal.
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null,
  email text not null,
  public_id text unique not null,
  role text not null default 'member' check (role in ('owner', 'seller', 'member')), -- owner: akses penuh; seller: cuma kelola produknya sendiri; member: user biasa
  verified boolean not null default false, -- centang biru. Independen dari role: owner SELALU otomatis verified; seller/member hanya verified kalau owner mengaktifkannya manual lewat panel
  banned_until timestamptz, -- null = not banned. If in the past, treated as expired (handled by app + cleanup job).
  ban_reason text,
  last_seen timestamptz, -- updated periodically by the app while the user has it open; drives online/offline status
  created_at timestamptz default now()
);

-- Sequence buat generate public_id berurutan
create sequence public.profile_seq start 1;

-- Format ID: "00000001", "00000002", dst. (8 digit, zero-padded)
-- User pertama = 00000001, user ke-100 = 00000100, dst.
create or replace function public.generate_public_id()
returns text language sql as $$
  select lpad(nextval('public.profile_seq')::text, 8, '0');
$$;

-- Role user yang sedang login & cek cepat apakah dia owner. Dipakai di RLS.
create or replace function public.current_role()
returns text language sql stable as $$
  select role from public.profiles where id = auth.uid();
$$;

create or replace function public.is_owner()
returns boolean language sql stable as $$
  select coalesce((select role = 'owner' from public.profiles where id = auth.uid()), false);
$$;

-- Otomatis buat row di profiles begitu ada user baru daftar lewat Supabase Auth.
-- Email yang cocok dengan OWNER_EMAIL otomatis kebagian role 'owner' + verified
-- otomatis true (owner selalu bercentang biru, tidak perlu diaktifkan manual).
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, username, email, public_id, role, verified)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)),
    new.email,
    public.generate_public_id(),
    case when new.email = 'iputu.aditya789@gmail.com' then 'owner' else 'member' end,
    new.email = 'iputu.aditya789@gmail.com'
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- RPC: owner mengangkat member jadi seller atau mencabutnya. security definer
-- karena perlu update kolom 'role' milik user LAIN (RLS profiles normal cuma
-- izinkan auth.uid() = id), tapi di dalam fungsi ini dicek manual bahwa
-- pemanggilnya memang owner, jadi tetap aman dari penyalahgunaan.
create or replace function public.set_seller_status(target_public_id text, make_seller boolean)
returns void language plpgsql security definer as $$
begin
  if not public.is_owner() then
    raise exception 'Hanya owner yang bisa mengubah status seller.';
  end if;
  update public.profiles
  set role = case when make_seller then 'seller' else 'member' end
  where public_id = target_public_id
    and role <> 'owner';
end;
$$;

-- RPC: owner memberi/mencabut centang biru SIAPA PUN secara independen dari
-- role (seller belum tentu verified, dan member biasa pun bisa diberi centang
-- biru kalau owner mau). Owner sendiri selalu verified otomatis dan tidak
-- bisa diubah lewat jalur ini.
create or replace function public.set_verified_status(target_public_id text, make_verified boolean)
returns void language plpgsql security definer as $$
begin
  if not public.is_owner() then
    raise exception 'Hanya owner yang bisa mengubah status centang biru.';
  end if;
  update public.profiles
  set verified = make_verified
  where public_id = target_public_id
    and role <> 'owner';
end;
$$;

-- ── Categories ───────────────────────────────────────────────────────────────
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  created_at timestamptz default now()
);

insert into public.categories (name) values
  ('Game (Roblox, MLBB, FF)'),
  ('E-Wallet (DANA, OVO, GoPay)'),
  ('Voucher'),
  ('Pulsa & Data'),
  ('Streaming'),
  ('Lainnya');

-- ── Products ─────────────────────────────────────────────────────────────────
create table public.products (
  id text primary key, -- keep using the short alphanumeric IDs already in use
  name text not null,
  category text not null,
  description text,
  phone text,
  images text[] default '{}',
  seller_id uuid references public.profiles(id) on delete set null, -- null = produk milik toko/owner; terisi = milik seller tsb
  created_at timestamptz default now()
);

create index idx_products_seller_id on public.products(seller_id);

-- ── Product interactions: likes / favorites / saves ──────────────────────────
create table public.product_likes (
  product_id text references public.products(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (product_id, user_id)
);

create table public.product_favorites (
  product_id text references public.products(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (product_id, user_id)
);

create table public.product_saves (
  product_id text references public.products(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (product_id, user_id)
);

-- ── Profile likes ──────────────────────────────────────────────────────────
create table public.profile_likes (
  profile_id uuid references public.profiles(id) on delete cascade,
  liker_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (profile_id, liker_id)
);

-- ── Comments ─────────────────────────────────────────────────────────────────
create table public.comments (
  id uuid primary key default gen_random_uuid(),
  product_id text references public.products(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  text text not null,
  created_at timestamptz default now()
);

create table public.comment_likes (
  comment_id uuid references public.comments(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (comment_id, user_id)
);

-- ── Notifications ─────────────────────────────────────────────────────────────
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  type text not null,
  message text not null,
  link text,
  read boolean default false,
  created_at timestamptz default now()
);

-- ============================================================================
-- Ban system
-- ============================================================================

-- Called by the app when a user's ban has expired, to permanently delete their account.
-- security definer lets this bypass RLS so it can delete from auth.users (normally
-- only the service_role key can do that) — but it only ever deletes the CALLING user's
-- own account, and only if their ban has actually expired, so it can't be abused.
create or replace function public.delete_my_account_if_ban_expired()
returns boolean language plpgsql security definer as $$
declare
  v_banned_until timestamptz;
begin
  select banned_until into v_banned_until from public.profiles where id = auth.uid();
  if v_banned_until is not null and v_banned_until <= now() then
    delete from auth.users where id = auth.uid(); -- cascades to profiles via FK
    return true;
  end if;
  return false;
end;
$$;

-- Bans/unbans a user. Restricted to authenticated callers at the DB level (matching
-- the same pattern used for products/categories above); the app UI only exposes this
-- to the owner account. duration_hours = null means a permanent ban until manually unbanned.
create or replace function public.ban_user(target_public_id text, duration_hours numeric, reason text)
returns void language plpgsql security definer as $$
begin
  update public.profiles
  set banned_until = case when duration_hours is null then '9999-12-31T23:59:59Z'::timestamptz else now() + (duration_hours || ' hours')::interval end,
      ban_reason = reason
  where public_id = target_public_id;
end;
$$;

create or replace function public.unban_user(target_public_id text)
returns void language plpgsql security definer as $$
begin
  update public.profiles set banned_until = null, ban_reason = null where public_id = target_public_id;
end;
$$;

-- ============================================================================
-- Row Level Security (RLS)
-- ============================================================================

alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.product_likes enable row level security;
alter table public.product_favorites enable row level security;
alter table public.product_saves enable row level security;
alter table public.profile_likes enable row level security;
alter table public.comments enable row level security;
alter table public.comment_likes enable row level security;
alter table public.notifications enable row level security;

-- Profiles: semua orang bisa baca (untuk profil publik), tapi cuma pemilik akun yang bisa update
create policy "Profiles are viewable by everyone" on public.profiles for select using (true);
create policy "Users can update own profile" on public.profiles for update using (auth.uid() = id);

-- Categories: semua bisa baca; cuma owner yang boleh ubah
create policy "Categories are viewable by everyone" on public.categories for select using (true);
create policy "Owner manages categories" on public.categories for all using (public.is_owner()) with check (public.is_owner());

-- Products: semua bisa baca. Owner bebas kelola semua produk; seller hanya
-- boleh kelola (insert/update/delete) produk miliknya sendiri (seller_id = dirinya).
create policy "Products are viewable by everyone" on public.products for select using (true);
create policy "Owner manages all products" on public.products for all using (public.is_owner()) with check (public.is_owner());
create policy "Sellers manage own products" on public.products for all
  using (public.current_role() = 'seller' and seller_id = auth.uid())
  with check (public.current_role() = 'seller' and seller_id = auth.uid());

-- Product likes/favorites/saves: semua bisa baca (perlu hitung jumlah & cek status),
-- tapi orang hanya bisa menambah/menghapus baris miliknya sendiri
create policy "Likes are viewable by everyone" on public.product_likes for select using (true);
create policy "Users manage own likes" on public.product_likes for insert with check (auth.uid() = user_id);
create policy "Users delete own likes" on public.product_likes for delete using (auth.uid() = user_id);

create policy "Favorites are viewable by everyone" on public.product_favorites for select using (true);
create policy "Users manage own favorites" on public.product_favorites for insert with check (auth.uid() = user_id);
create policy "Users delete own favorites" on public.product_favorites for delete using (auth.uid() = user_id);

create policy "Saves are viewable by everyone" on public.product_saves for select using (true);
create policy "Users manage own saves" on public.product_saves for insert with check (auth.uid() = user_id);
create policy "Users delete own saves" on public.product_saves for delete using (auth.uid() = user_id);

-- Profile likes
create policy "Profile likes are viewable by everyone" on public.profile_likes for select using (true);
create policy "Users manage own profile likes" on public.profile_likes for insert with check (auth.uid() = liker_id);
create policy "Users delete own profile likes" on public.profile_likes for delete using (auth.uid() = liker_id);

-- Comments: semua bisa baca; user login bisa tulis komentar sendiri;
-- hapus: owner boleh hapus komentar siapa saja, user lain hanya boleh hapus
-- komentar miliknya sendiri.
create policy "Comments are viewable by everyone" on public.comments for select using (true);
create policy "Users can post own comments" on public.comments for insert with check (auth.uid() = user_id);
create policy "Owner, author, or product seller can delete comments" on public.comments for delete using (
  public.is_owner()
  or auth.uid() = user_id
  or exists (select 1 from public.products p where p.id = comments.product_id and p.seller_id = auth.uid())
);

-- Comment likes: siapa pun yang login bisa like/unlike komentar, tapi cuma
-- baris miliknya sendiri yang bisa dia ubah/hapus.
create policy "Comment likes are viewable by everyone" on public.comment_likes for select using (true);
create policy "Users can like comments" on public.comment_likes for insert with check (auth.uid() = user_id);
create policy "Users can unlike own comment likes" on public.comment_likes for delete using (auth.uid() = user_id);

-- Notifications: orang hanya bisa baca & update notifikasi miliknya sendiri.
-- Insert dibuka untuk semua user login (karena notifikasi dibuat oleh user
-- lain yang melakukan aksi, misal komentar/like), TAPI tipe "admin-broadcast"
-- dan "new-product" dikunci untuk owner saja supaya tidak ada yang bisa
-- berpura-pura jadi pengumuman resmi toko.
create policy "Users see own notifications" on public.notifications for select using (auth.uid() = user_id);
create policy "Users send notifications, owner-only broadcast types" on public.notifications for insert with check (
  auth.role() = 'authenticated'
  and (type not in ('admin-broadcast', 'new-product') or public.is_owner())
);
create policy "Users update own notifications" on public.notifications for update using (auth.uid() = user_id);

-- ── Friends ──────────────────────────────────────────────────────────────────
-- Model satu-arah sederhana: kalau A menambahkan B, artinya A menganggap B
-- teman (mirip "mengikuti"). Jumlah teman ditampilkan publik (lewat RPC
-- get_friend_count di bawah), tapi DAFTAR siapa-siapa-nya tetap privat —
-- RLS select hanya mengizinkan kamu melihat baris milikmu sendiri.
create table public.friends (
  user_id uuid references public.profiles(id) on delete cascade,
  friend_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (user_id, friend_id),
  constraint friends_no_self check (user_id <> friend_id)
);
create index idx_friends_friend_id on public.friends(friend_id);

alter table public.friends enable row level security;
create policy "Users see own friend list" on public.friends for select using (auth.uid() = user_id);
create policy "Users add own friends" on public.friends for insert with check (auth.uid() = user_id);
create policy "Users remove own friends" on public.friends for delete using (auth.uid() = user_id);
grant select, insert, delete on public.friends to authenticated;

-- RPC publik: hanya mengembalikan ANGKA jumlah teman seseorang, tanpa membuka
-- daftarnya — ini yang membuat "jumlah teman publik, daftar teman privat" bisa
-- terjadi sekaligus (function security definer membaca tabel yang dibatasi RLS).
create or replace function public.get_friend_count(target_user_id uuid)
returns bigint language sql stable security definer as $$
  select count(*) from public.friends where user_id = target_user_id;
$$;

-- RPC: dipanggil saat seseorang like sebuah produk, untuk memberi notifikasi
-- ke semua orang yang menjadikan dia teman ("temanmu si X menyukai produk
-- ini..."). Harus security definer karena si pelaku (p_liker_id) sendiri TIDAK
-- diizinkan oleh RLS untuk tahu siapa saja yang menjadikan dia teman (privasi),
-- jadi pencarian daftar penerima notifikasi ini wajib dilakukan di sisi server.
create or replace function public.notify_friends_of_product_like(p_liker_id uuid, p_product_id text, p_product_name text)
returns void language plpgsql security definer as $$
declare
  liker_username text;
begin
  if p_liker_id <> auth.uid() then
    raise exception 'Tidak diizinkan.';
  end if;
  select username into liker_username from public.profiles where id = p_liker_id;
  if liker_username is null then return; end if;
  insert into public.notifications (user_id, type, message, link)
  select f.user_id, 'friend-like-product',
         liker_username || ' menyukai produk "' || p_product_name || '". Yuk lihat juga! 👀',
         '/produk/' || p_product_id
  from public.friends f
  where f.friend_id = p_liker_id;
end;
$$;

-- ============================================================================
-- Function execute permissions
-- ============================================================================
-- Any logged-in user can call these (the app UI is what restricts ban_user/unban_user
-- to the owner account, same pattern as products/categories management above).
grant execute on function public.delete_my_account_if_ban_expired() to authenticated;
grant execute on function public.ban_user(text, numeric, text) to authenticated;
grant execute on function public.unban_user(text) to authenticated;
grant execute on function public.current_role() to anon, authenticated;
grant execute on function public.is_owner() to anon, authenticated;
grant execute on function public.set_seller_status(text, boolean) to authenticated;
grant execute on function public.set_verified_status(text, boolean) to authenticated;
grant execute on function public.get_friend_count(uuid) to anon, authenticated;
grant execute on function public.notify_friends_of_product_like(uuid, text, text) to authenticated;

-- Grant tabel eksplisit untuk comments/comment_likes (selain RLS di atas).
-- Supabase biasanya otomatis memberi ini, tapi dipastikan ulang di sini.
grant select on public.comments to anon, authenticated;
grant insert, delete on public.comments to authenticated;
grant select on public.comment_likes to anon, authenticated;
grant insert, delete on public.comment_likes to authenticated;

-- ============================================================================
-- Selesai! Setelah ini jalan tanpa error, lanjut ke langkah berikutnya di chat.
-- ============================================================================
