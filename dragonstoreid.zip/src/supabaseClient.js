import { createClient } from '@supabase/supabase-js';

// ANON KEY aman di frontend HANYA karena RLS aktif di semua table.
// ANON KEY hanya bisa baca/tulis sesuai RLS policy — tidak bisa akses data orang lain.
// Service Role Key (admin) HANYA ada di server (api/auth.js — Vercel Serverless Function).
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('❌ Supabase credentials belum diset. Buat file .env dan isi VITE_SUPABASE_URL + VITE_SUPABASE_ANON_KEY.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true, // perlu untuk email verification callback
  }
});

// ── Secure API caller — panggil Vercel Serverless Function, bukan Supabase langsung ──
// Operasi sensitif (signup, admin) lewat sini supaya service role key aman di server.
export async function secureAuth(action, payload = {}) {
  const res = await fetch('/api/auth', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action, payload }),
  });

  const data = await res.json();

  if (!res.ok) {
    const err = new Error(data.error || 'Server error');
    err.status = res.status;
    throw err;
  }

  return data;
}
