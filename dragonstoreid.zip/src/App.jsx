import { useState, useEffect, useRef } from "react";
import { Routes, Route, useNavigate, useParams, useLocation, Link } from "react-router-dom";
import { supabase } from "./supabaseClient";
import * as db from "./db";

// ─── Rate Limit Helper ────────────────────────────────────────────────────────
function getNextAvailableSignupTime() {
  const lastSignupTime = localStorage.getItem('lastSignupAttempt');
  if (!lastSignupTime) return null;
  
  const lastTime = new Date(parseInt(lastSignupTime));
  const now = new Date();
  const oneHourLater = new Date(lastTime.getTime() + 60 * 60 * 1000);
  
  if (now < oneHourLater) {
    // Next hour at :00 minutes
    const nextHour = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate(),
      now.getHours() + 1,
      0,
      0
    );
    return nextHour;
  }
  return null;
}

// ─── Constants ───────────────────────────────────────────────────────────────
const OWNER_EMAIL = db.OWNER_EMAIL;
const STORE_NAME = "Dragon Store";

function genId() {
  return Math.random().toString(36).substr(2, 9).toUpperCase();
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const S = {
  // Layout
  app: { minHeight: "100vh", background: "#0A0A0F", color: "#E8E8F0", fontFamily: "'Inter', sans-serif", display: "flex", flexDirection: "column" },
  page: { flex: 1, maxWidth: 480, width: "100%", margin: "0 auto", padding: "0 0 80px 0" },
  // Nav
  nav: { background: "linear-gradient(135deg,#1A0A0A 0%,#120812 100%)", borderBottom: "1px solid #3D0D0D", padding: "14px 20px", position: "sticky", top: 0, zIndex: 50 },
  navLogo: { fontSize: 18, fontWeight: 800, background: "linear-gradient(90deg,#FF3B3B,#FF8C00)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", letterSpacing: "-0.5px" },
  navIcon: { background: "none", border: "none", color: "#E8E8F0", cursor: "pointer", padding: 8, borderRadius: 8, fontSize: 20, display: "flex", alignItems: "center" },
  // Bottom Tab
  tabBar: { position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 480, background: "#0F0F1A", borderTop: "1px solid #1E1E30", display: "flex", justifyContent: "space-around", padding: "8px 0 12px", zIndex: 50 },
  tabBtn: (active) => ({ background: "none", border: "none", color: active ? "#FF3B3B" : "#666", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, fontSize: 10, fontWeight: active ? 700 : 400, padding: "4px 12px", transition: "color 0.2s" }),
  // Cards
  productCard: { background: "#12121E", border: "1px solid #1E1E30", borderRadius: 16, overflow: "hidden", cursor: "pointer", transition: "transform 0.15s,border-color 0.15s", marginBottom: 12 },
  productImg: { width: "100%", height: 180, objectFit: "cover", background: "#1A1A2E" },
  productBody: { padding: "12px 14px" },
  productName: { fontSize: 15, fontWeight: 700, marginBottom: 4, color: "#F0F0FF" },
  productCat: { fontSize: 11, color: "#FF6B35", fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.5 },
  // Buttons
  btnPrimary: { background: "linear-gradient(135deg,#CC1818,#FF3B3B)", color: "#fff", border: "none", borderRadius: 12, padding: "13px 24px", fontWeight: 700, fontSize: 15, cursor: "pointer", width: "100%", letterSpacing: 0.3 },
  btnSecondary: { background: "#1E1E30", color: "#E8E8F0", border: "1px solid #2E2E45", borderRadius: 12, padding: "12px 24px", fontWeight: 600, fontSize: 14, cursor: "pointer", width: "100%" },
  btnWA: { background: "linear-gradient(135deg,#128C7E,#25D366)", color: "#fff", border: "none", borderRadius: 12, padding: "13px 24px", fontWeight: 700, fontSize: 15, cursor: "pointer", width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 },
  btnDanger: { background: "linear-gradient(135deg,#8B0000,#CC1818)", color: "#fff", border: "none", borderRadius: 10, padding: "9px 16px", fontWeight: 600, fontSize: 13, cursor: "pointer" },
  btnSmall: { background: "#1E1E30", color: "#ccc", border: "1px solid #2E2E45", borderRadius: 8, padding: "7px 12px", fontWeight: 600, fontSize: 12, cursor: "pointer" },
  // Inputs
  input: { width: "100%", background: "#12121E", border: "1px solid #2E2E45", borderRadius: 12, padding: "13px 16px", color: "#E8E8F0", fontSize: 14, outline: "none", boxSizing: "border-box" },
  textarea: { width: "100%", background: "#12121E", border: "1px solid #2E2E45", borderRadius: 12, padding: "13px 16px", color: "#E8E8F0", fontSize: 14, outline: "none", resize: "vertical", minHeight: 100, boxSizing: "border-box", fontFamily: "inherit" },
  select: { width: "100%", background: "#12121E", border: "1px solid #2E2E45", borderRadius: 12, padding: "13px 16px", color: "#E8E8F0", fontSize: 14, outline: "none", boxSizing: "border-box", appearance: "none" },
  label: { display: "block", fontSize: 12, fontWeight: 600, color: "#888", marginBottom: 6, textTransform: "uppercase", letterSpacing: 0.5 },
  formGroup: { marginBottom: 18 },
  // Typography
  h1: { fontSize: 26, fontWeight: 800, color: "#F0F0FF", marginBottom: 6 },
  h2: { fontSize: 20, fontWeight: 700, color: "#F0F0FF", marginBottom: 12 },
  subtitle: { fontSize: 13, color: "#888" },
  // Misc
  badge: (color) => ({ background: color || "#1E1E30", color: "#fff", borderRadius: 20, padding: "3px 10px", fontSize: 11, fontWeight: 700, display: "inline-block" }),
  divider: { height: 1, background: "#1E1E30", margin: "16px 0" },
  toast: { position: "fixed", top: 20, left: "50%", transform: "translateX(-50%)", background: "#1E1E30", border: "1px solid #FF3B3B", color: "#fff", padding: "12px 24px", borderRadius: 12, zIndex: 999, fontWeight: 600, fontSize: 14, whiteSpace: "nowrap", boxShadow: "0 4px 24px rgba(255,59,59,0.3)" },
  emptyState: { textAlign: "center", padding: "60px 20px", color: "#555" },
  section: { padding: "0 16px" },
  // Interaction buttons (like/favorite/save)
  interactBtn: (active, activeColor) => ({
    background: active ? `${activeColor}22` : "#12121E",
    border: `1px solid ${active ? activeColor : "#1E1E30"}`,
    color: active ? activeColor : "#888",
    borderRadius: 12, padding: "10px 14px", fontWeight: 700, fontSize: 13,
    cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, flex: 1,
    transition: "all 0.15s",
  }),
  // Notification badge dot on bell/nav icons
  notifDot: { position: "absolute", top: 2, right: 2, width: 9, height: 9, borderRadius: "50%", background: "#FF3B3B", border: "2px solid #1A0A0A" },
  // Comment box
  commentBox: { background: "#12121E", border: "1px solid #1E1E30", borderRadius: 14, padding: "12px 14px", marginBottom: 10 },
};

// ─── Toast ────────────────────────────────────────────────────────────────────
function Toast({ msg, onDone }) {
  useEffect(() => { const t = setTimeout(onDone, 2500); return () => clearTimeout(t); }, []);
  return <div style={S.toast}>{msg}</div>;
}

// ─── Image placeholder ────────────────────────────────────────────────────────
function ImgBox({ src, style }) {
  const [err, setErr] = useState(false);
  if (!src || err) return <div style={{ ...style, background: "linear-gradient(135deg,#1A0A1A,#0A0A1A)", display: "flex", alignItems: "center", justifyContent: "center", color: "#333", fontSize: 40 }}>🐉</div>;
  return <img src={src} style={style} onError={() => setErr(true)} alt="" />;
}

function Spinner() {
  return <div style={S.emptyState}><div style={{ fontSize: 30 }}>🐉</div><p style={{ fontSize: 13 }}>Memuat...</p></div>;
}

// Blue checkmark shown next to a username. The OWNER is always automatically
// verified. Everyone else (including sellers — being a seller does NOT
// automatically grant verification) is only verified if the owner explicitly
// turned it on for that account from the owner panel.
function isVerified(p) {
  return !!p && (p.role === "owner" || p.verified === true);
}
function VerifiedBadge({ size = 15 }) {
  return (
    <img
      src="/verified-badge.png"
      alt="Terverifikasi"
      title="Akun terverifikasi"
      style={{ width: size, height: size, flexShrink: 0, display: "inline-block" }}
    />
  );
}

// Shares a link via the native share sheet on mobile, or copies it to the
// clipboard on desktop (where navigator.share usually isn't available).
async function shareLink({ title, text, path, showToast }) {
  const url = `${window.location.origin}${path}`;
  if (navigator.share) {
    try {
      await navigator.share({ title, text, url });
      return;
    } catch (err) {
      if (err?.name === "AbortError") return; // user cancelled the share sheet, no need to fall back
    }
  }
  try {
    await navigator.clipboard.writeText(url);
    showToast?.("Link disalin ke clipboard! 🔗");
  } catch {
    showToast?.(url); // last-resort fallback so the user can still see/copy the link manually
  }
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(null); // profile row: { id, username, email, public_id }
  const [authLoading, setAuthLoading] = useState(true);
  const [toast, setToast] = useState(null);
  const navigate = useNavigate();
  const location = useLocation();
  const [unread, setUnread] = useState(0);
  const [banInfo, setBanInfo] = useState(null); // null = not banned, { until, reason } = banned

  const showToast = (msg) => setToast(msg);

  // Load the profile whenever the Supabase auth session changes (login/logout/token refresh).
  // This is what makes the account global: the session lives on Supabase's server,
  // so the same login works from any device/browser, not just the one that created it.
  // SIGNED_IN can also fire right after the user clicks the email verification link
  // (Supabase redirects back here with a session already in the URL).
  useEffect(() => {
    let active = true;
    const loadProfile = async () => {
      const profile = await db.getMyProfile();
      if (active) { setUser(profile); setAuthLoading(false); }
      // Check ban status right after loading the profile. If the ban has expired,
      // this call also deletes the account permanently and signs out automatically.
      if (profile) {
        const status = await db.checkMyBanStatus();
        if (!active) return;
        if (status.justDeleted) {
          setUser(null);
          showToast("Akun ini telah dihapus permanen karena masa banned telah berakhir.");
        } else if (status.banned) {
          setBanInfo({ until: status.until, reason: status.reason });
        } else {
          setBanInfo(null);
        }
      } else {
        setBanInfo(null);
      }
    };
    loadProfile();
    const { data: listener } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_IN" && window.location.pathname === '/verify') {
        // Biarkan VerifyEmailPage yang handle redirect
        return;
      }
      loadProfile();
    });
    return () => { active = false; listener?.subscription?.unsubscribe(); };
  }, []);

  // Helper compatible with old navigate(page, extra) calls used throughout the file.
  const go = (p, extra) => {
    const routes = {
      hub: "/",
      search: extra ? `/cari?q=${encodeURIComponent(extra)}` : "/cari",
      dashboard: "/dashboard",
      profile: "/profil",
      "login-daftar": "/masuk",
      detail: `/produk/${extra}`,
      owner: "/owner",
      seller: "/jual",
      friends: "/teman",
      notifikasi: "/notifikasi",
      publicProfile: `/profile/${extra}`,
    };
    navigate(routes[p] ?? "/");
    window.scrollTo(0, 0);
  };

  // Any action that requires login funnels through here; if not logged in,
  // redirect to login and show a clear reason instead of silently failing.
  const requireLogin = () => {
    if (user) return true;
    showToast("Silakan masuk untuk melakukan aksi ini.");
    go("login-daftar");
    return false;
  };

  const login = (profile) => { setUser(profile); showToast(`Selamat datang, ${profile.username}! 🐉`); go("hub"); };
  const logout = async () => { await db.signOut(); setUser(null); setBanInfo(null); showToast("Berhasil keluar."); go("hub"); };

  const isOwner = user?.email === OWNER_EMAIL;
  const isSeller = user?.role === "seller";

  const refreshUnread = async () => {
    if (!user) { setUnread(0); return; }
    setUnread(await db.getUnreadNotificationCount(user.id));
  };
  useEffect(() => { refreshUnread(); }, [user, location.pathname]);

  // Online/offline presence: ping last_seen right away and then every 60s while
  // logged in and the app is open. Other people see this via isOnline(last_seen).
  useEffect(() => {
    if (!user) return;
    db.touchLastSeen(user.id);
    const interval = setInterval(() => db.touchLastSeen(user.id), 60 * 1000);
    return () => clearInterval(interval);
  }, [user?.id]);

  const tabs = [
    { id: "hub", path: "/", label: "Beranda", icon: "🏠" },
    { id: "search", path: "/cari", label: "Cari", icon: "🔍" },
    { id: "dashboard", path: "/dashboard", label: "Dashboard", icon: "📊" },
    { id: "profile", path: "/profil", label: "Profil", icon: "👤" },
  ];

  if (authLoading) return <div style={S.app}><Spinner /></div>;

  // Banned accounts see only this screen — no other part of the app is reachable
  // until the ban is lifted (by owner) or expires (auto-deletes the account).
  if (user && banInfo) {
    const untilStr = banInfo.until.toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" });
    const isPermanent = banInfo.until.getFullYear() > 9000;
    return (
      <div style={S.app}>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet" />
        <div style={{ ...S.section, paddingTop: 60, textAlign: "center", maxWidth: 420, margin: "0 auto" }}>
          <div style={{ fontSize: 60, marginBottom: 16 }}>🚫</div>
          <div style={S.h1}>Akun Dibanned</div>
          <p style={{ ...S.subtitle, marginBottom: 20, lineHeight: 1.6 }}>
            Akun kamu telah dibanned{banInfo.reason ? ` dengan alasan: "${banInfo.reason}"` : ""}.
          </p>
          <div style={{ background: "#12121E", border: "1px solid #1E1E30", borderRadius: 12, padding: "14px 18px", marginBottom: 24 }}>
            <div style={{ fontSize: 11, color: "#888", marginBottom: 4 }}>{isPermanent ? "Status" : "Banned sampai"}</div>
            <div style={{ fontSize: 14, fontWeight: 700, color: "#FF3B3B" }}>{isPermanent ? "Permanen (akan dihapus saat di-unban tidak terjadi)" : untilStr}</div>
          </div>
          {!isPermanent && (
            <p style={{ fontSize: 12, color: "#666", marginBottom: 24 }}>Jika masa banned berakhir dan tidak di-unban, akun ini akan terhapus permanen secara otomatis.</p>
          )}
          <button style={{ ...S.btnWA, marginBottom: 10 }} onClick={() => window.open(`https://wa.me/${db.OWNER_PHONE}`, "_blank")}>
            <span style={{ fontSize: 20 }}>💬</span> Hubungi Owner
          </button>
          <button style={S.btnSecondary} onClick={logout}>Keluar dari Akun</button>
        </div>
      </div>
    );
  }

  return (
    <div style={S.app}>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet" />
      {toast && <Toast msg={toast} onDone={() => setToast(null)} />}

      {/* Top Nav */}
      <nav style={S.nav}>
        <div className="ds-nav-inner">
          <span style={S.navLogo} onClick={() => go("hub")}>🐉 {STORE_NAME}</span>
          {!user ? (
            <button style={{ ...S.navIcon, background: "linear-gradient(135deg,#CC1818,#FF3B3B)", borderRadius: 10, padding: "7px 14px", color: "#fff", fontSize: 13, fontWeight: 700 }} onClick={() => go("login-daftar")}>Masuk</button>
          ) : (
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              {isOwner && <button style={{ ...S.navIcon, background: "#2A0A0A", borderRadius: 10, padding: "6px 12px", fontSize: 12, color: "#FF6B35", fontWeight: 700, border: "1px solid #3D1010" }} onClick={() => go("owner")}>⚡ Owner</button>}
              {isSeller && <button style={{ ...S.navIcon, background: "#0A1A2A", borderRadius: 10, padding: "6px 12px", fontSize: 12, color: "#3B9CFF", fontWeight: 700, border: "1px solid #103050" }} onClick={() => go("seller")}>🏷️ Jual</button>}
              <div style={{ position: "relative" }}>
                <button style={S.navIcon} onClick={() => go("notifikasi")}>🔔</button>
                {unread > 0 && <span style={S.notifDot} />}
              </div>
              <div style={{ width: 36, height: 36, borderRadius: "50%", background: "linear-gradient(135deg,#CC1818,#FF8C00)", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 15, cursor: "pointer" }} onClick={() => go("profile")}>
                {user.username[0].toUpperCase()}
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Page Content */}
      <div className="ds-page">
        <Routes>
          <Route path="/" element={<HubPage navigate={go} />} />
          <Route path="/cari" element={<SearchPage navigate={go} />} />
          <Route path="/dashboard" element={<DashboardPage navigate={go} user={user} />} />
          <Route path="/profil" element={<ProfilePage user={user} logout={logout} navigate={go} showToast={showToast} setUser={setUser} />} />
          <Route path="/masuk" element={<LoginPage login={login} navigate={go} showToast={showToast} />} />
          <Route path="/verify" element={<VerifyEmailPage />} />
          <Route path="/produk/:id" element={<DetailPage navigate={go} user={user} showToast={showToast} requireLogin={requireLogin} isOwner={isOwner} isSeller={isSeller} />} />
          <Route path="/owner" element={isOwner ? <OwnerPage showToast={showToast} navigate={go} /> : <div style={{ ...S.emptyState }}><div style={{ fontSize: 50 }}>🚫</div><p>Akses ditolak.</p></div>} />
          <Route path="/jual" element={isSeller ? <SellerPage user={user} showToast={showToast} navigate={go} /> : <div style={{ ...S.emptyState, paddingTop: 60 }}><div style={{ fontSize: 50 }}>🚫</div><p>Akses ditolak. Halaman ini khusus seller.</p></div>} />
          <Route path="/teman" element={<FriendsSearchPage user={user} showToast={showToast} navigate={go} requireLogin={requireLogin} />} />
          <Route path="/notifikasi" element={user ? <NotificationsPage user={user} navigate={go} onRead={refreshUnread} /> : <div style={{ ...S.emptyState, paddingTop: 60 }}><div style={{ fontSize: 50 }}>🔒</div><p>Masuk untuk melihat notifikasi.</p><button style={{ ...S.btnSecondary, marginTop: 16 }} onClick={() => go("login-daftar")}>Masuk</button></div>} />
          <Route path="/profile/:pid" element={<PublicProfilePage navigate={go} currentUser={user} showToast={showToast} requireLogin={requireLogin} />} />
          <Route path="*" element={<div style={{ ...S.emptyState, paddingTop: 60 }}><div style={{ fontSize: 50 }}>😕</div><p>Halaman tidak ditemukan.</p><button style={{ ...S.btnSecondary, marginTop: 16 }} onClick={() => go("hub")}>Kembali ke Beranda</button></div>} />
        </Routes>
      </div>

      {/* Bottom Tab Bar (becomes a top row on tablet/desktop, see index.css) */}
      <div className="ds-tabbar">
        {tabs.map(t => (
          <button key={t.id} style={S.tabBtn(location.pathname === t.path)} onClick={() => go(t.id)}>
            <span style={{ fontSize: 22 }}>{t.icon}</span>
            {t.label}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Hub Page ─────────────────────────────────────────────────────────────────
function HubPage({ navigate }) {
  const [products, setProducts] = useState(null);
  const [categories, setCategories] = useState([]);
  const [likeCounts, setLikeCounts] = useState({});
  const [activeCat, setActiveCat] = useState("Semua");
  const [search, setSearch] = useState("");

  useEffect(() => {
    let active = true;
    (async () => {
      const [prods, cats] = await Promise.all([db.getProducts(), db.getCategories()]);
      if (!active) return;
      setProducts(prods);
      setCategories(cats);
      const counts = await db.getInteractionCountsBulk("likes", prods.map(p => p.id));
      if (active) setLikeCounts(counts);
    })();
    return () => { active = false; };
  }, []);

  if (products === null) return <Spinner />;

  const filtered = products
    .filter(p => {
      const matchCat = activeCat === "Semua" || p.category === activeCat;
      const q = search.toLowerCase();
      const matchSearch = p.name.toLowerCase().includes(q) || p.id.toLowerCase().includes(q);
      return matchCat && matchSearch;
    })
    .sort((a, b) => (likeCounts[b.id] || 0) - (likeCounts[a.id] || 0));

  return (
    <div>
      {/* Hero */}
      <div style={{ background: "linear-gradient(135deg,#1A0A0A 0%,#120818 60%,#0A0A1A 100%)", padding: "28px 20px 24px", marginBottom: 0 }}>
        <div style={{ fontSize: 11, color: "#FF6B35", fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", marginBottom: 8 }}>⚡ Terpercaya & Cepat</div>
        <div style={{ fontSize: 28, fontWeight: 900, color: "#F0F0FF", lineHeight: 1.2, marginBottom: 10 }}>
          Top Up &<br /><span style={{ background: "linear-gradient(90deg,#FF3B3B,#FF8C00)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Digital Store</span>
        </div>
        <p style={{ fontSize: 13, color: "#888", marginBottom: 18 }}>Game, E-Wallet, Voucher & lebih banyak lagi</p>
        {/* Search bar */}
        <div style={{ position: "relative" }}>
          <span style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", fontSize: 16 }}>🔍</span>
          <input
            style={{ ...S.input, paddingLeft: 42, borderRadius: 14, background: "#0F0F1A" }}
            placeholder="Cari produk atau Product ID..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            onKeyDown={e => e.key === "Enter" && search.trim() && navigate("search", search.trim())}
          />
        </div>
      </div>

      {/* Categories */}
      <div className="ds-hide-scrollbar" style={{ overflowX: "auto", display: "flex", gap: 8, padding: "16px 16px 8px", scrollbarWidth: "none" }}>
        {["Semua", ...categories].map(c => (
          <button key={c} onClick={() => setActiveCat(c)} style={{
            background: activeCat === c ? "linear-gradient(135deg,#CC1818,#FF3B3B)" : "#12121E",
            color: activeCat === c ? "#fff" : "#aaa",
            border: activeCat === c ? "none" : "1px solid #1E1E30",
            borderRadius: 20, padding: "7px 16px", fontWeight: 700, fontSize: 12,
            cursor: "pointer", whiteSpace: "nowrap", flexShrink: 0
          }}>{c}</button>
        ))}
      </div>

      {/* Products */}
      <div style={{ padding: "8px 16px" }}>
        {filtered.length === 0 ? (
          <div style={S.emptyState}><div style={{ fontSize: 50, marginBottom: 12 }}>🐉</div><p style={{ color: "#555" }}>{products.length === 0 ? "Belum ada produk tersedia." : "Produk tidak ditemukan."}</p></div>
        ) : (
          <div className="ds-grid">
            {filtered.map(p => <ProductCardSmall key={p.id} product={p} navigate={navigate} likeCount={likeCounts[p.id] || 0} />)}
          </div>
        )}
      </div>
    </div>
  );
}

function ProductCardSmall({ product, navigate, likeCount = 0 }) {
  const img = product.images?.[0];
  return (
    <div style={{ background: "#12121E", border: "1px solid #1E1E30", borderRadius: 14, overflow: "hidden", cursor: "pointer" }} onClick={() => navigate("detail", product.id)}>
      <ImgBox src={img} style={{ width: "100%", height: 120, objectFit: "cover" }} />
      <div style={{ padding: "10px 12px 12px" }}>
        <div style={{ fontSize: 10, color: "#FF6B35", fontWeight: 700, marginBottom: 4, textTransform: "uppercase" }}>{product.category}</div>
        <div style={{ fontSize: 13, fontWeight: 700, color: "#F0F0FF", lineHeight: 1.3, marginBottom: likeCount > 0 ? 4 : 0 }}>{product.name}</div>
        {likeCount > 0 && <div style={{ fontSize: 11, color: "#FF3B3B", fontWeight: 600 }}>👍 {likeCount}</div>}
      </div>
    </div>
  );
}

// ─── Search Page ──────────────────────────────────────────────────────────────
function SearchPage({ navigate }) {
  const location = useLocation();
  const initialQuery = new URLSearchParams(location.search).get("q") || "";
  const [q, setQ] = useState(initialQuery);
  const [products, setProducts] = useState(null);
  const [categories, setCategories] = useState([]);
  const [likeCounts, setLikeCounts] = useState({});
  const [activeCat, setActiveCat] = useState("Semua");

  useEffect(() => { setQ(initialQuery); }, [initialQuery]);

  useEffect(() => {
    let active = true;
    (async () => {
      const [prods, cats] = await Promise.all([db.getProducts(), db.getCategories()]);
      if (!active) return;
      setProducts(prods);
      setCategories(cats);
      const counts = await db.getInteractionCountsBulk("likes", prods.map(p => p.id));
      if (active) setLikeCounts(counts);
    })();
    return () => { active = false; };
  }, []);

  if (products === null) return <Spinner />;

  const results = products
    .filter(p => {
      const ql = q.toLowerCase();
      const matchQ = q === "" || p.name.toLowerCase().includes(ql) || p.id.toLowerCase().includes(ql) || p.description?.toLowerCase().includes(ql);
      const matchCat = activeCat === "Semua" || p.category === activeCat;
      return matchQ && matchCat;
    })
    .sort((a, b) => (likeCounts[b.id] || 0) - (likeCounts[a.id] || 0));

  return (
    <div style={S.section}>
      <div style={{ paddingTop: 20, marginBottom: 16 }}>
        <div style={S.h2}>Cari Produk</div>
        <div style={{ position: "relative" }}>
          <span style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", fontSize: 16 }}>🔍</span>
          <input style={{ ...S.input, paddingLeft: 42 }} placeholder="Nama produk, kategori..." value={q} onChange={e => setQ(e.target.value)} autoFocus />
        </div>
      </div>

      <div className="ds-hide-scrollbar" style={{ overflowX: "auto", display: "flex", gap: 8, marginBottom: 16, scrollbarWidth: "none" }}>
        {["Semua", ...categories].map(c => (
          <button key={c} onClick={() => setActiveCat(c)} style={{
            background: activeCat === c ? "linear-gradient(135deg,#CC1818,#FF3B3B)" : "#12121E",
            color: activeCat === c ? "#fff" : "#aaa",
            border: activeCat === c ? "none" : "1px solid #1E1E30",
            borderRadius: 20, padding: "6px 14px", fontWeight: 700, fontSize: 12,
            cursor: "pointer", whiteSpace: "nowrap", flexShrink: 0
          }}>{c}</button>
        ))}
      </div>

      {results.length === 0 ? (
        <div style={S.emptyState}><div style={{ fontSize: 50, marginBottom: 12 }}>🔍</div><p>Tidak ada hasil ditemukan.</p></div>
      ) : (
        results.map(p => <ProductCardRow key={p.id} product={p} navigate={navigate} likeCount={likeCounts[p.id] || 0} />)
      )}
    </div>
  );
}

function ProductCardRow({ product, navigate, likeCount = 0 }) {
  const img = product.images?.[0];
  return (
    <div style={{ ...S.productCard, display: "flex", gap: 0 }} onClick={() => navigate("detail", product.id)}>
      <ImgBox src={img} style={{ width: 90, height: 90, objectFit: "cover", flexShrink: 0 }} />
      <div style={{ padding: "12px 14px", flex: 1 }}>
        <div style={{ fontSize: 10, color: "#FF6B35", fontWeight: 700, textTransform: "uppercase", marginBottom: 4 }}>{product.category}</div>
        <div style={{ fontSize: 14, fontWeight: 700, color: "#F0F0FF" }}>{product.name}</div>
        <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
          <span style={{ fontSize: 11, color: "#666" }}>ID: {product.id}</span>
          {likeCount > 0 && <span style={{ fontSize: 11, color: "#FF3B3B", fontWeight: 600 }}>👍 {likeCount}</span>}
        </div>
      </div>
    </div>
  );
}

// ─── Dashboard Page ───────────────────────────────────────────────────────────
function DashboardPage({ navigate, user }) {
  const [products, setProducts] = useState(null);
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    let active = true;
    (async () => {
      const [prods, cats] = await Promise.all([db.getProducts(), db.getCategories()]);
      if (active) { setProducts(prods); setCategories(cats); }
    })();
    return () => { active = false; };
  }, []);

  if (products === null) return <Spinner />;

  const byCategory = categories.map(c => ({ name: c, count: products.filter(p => p.category === c).length })).filter(c => c.count > 0);

  return (
    <div style={S.section}>
      <div style={{ paddingTop: 20 }}>
        <div style={S.h1}>Dashboard</div>
        <p style={S.subtitle}>Ringkasan Dragon Store ID</p>
      </div>
      <div style={S.divider} />

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20, maxWidth: 480 }}>
        <StatCard icon="📦" label="Total Produk" value={products.length} color="#FF3B3B" />
        <StatCard icon="📂" label="Kategori" value={categories.length} color="#FF8C00" />
      </div>

      {/* Category breakdown */}
      <div style={{ background: "#12121E", border: "1px solid #1E1E30", borderRadius: 16, padding: 16, marginBottom: 20 }}>
        <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 12, color: "#F0F0FF" }}>Produk per Kategori</div>
        {byCategory.length === 0 ? <p style={{ color: "#555", fontSize: 13 }}>Belum ada produk.</p> : byCategory.map(c => (
          <div key={c.name} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: "1px solid #1A1A2E" }}>
            <span style={{ fontSize: 13 }}>{c.name}</span>
            <span style={S.badge("#CC1818")}>{c.count}</span>
          </div>
        ))}
      </div>

      {/* Recent products */}
      <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 12, color: "#F0F0FF" }}>Produk Terbaru</div>
      {products.slice(0, 4).map(p => <ProductCardRow key={p.id} product={p} navigate={navigate} />)}
      {products.length > 4 && <button style={S.btnSecondary} onClick={() => navigate("hub")}>Lihat Semua →</button>}
    </div>
  );
}

function StatCard({ icon, label, value, color }) {
  return (
    <div style={{ background: "#12121E", border: `1px solid ${color}30`, borderRadius: 16, padding: "18px 16px" }}>
      <div style={{ fontSize: 28, marginBottom: 8 }}>{icon}</div>
      <div style={{ fontSize: 28, fontWeight: 900, color }}>{value}</div>
      <div style={{ fontSize: 12, color: "#888", fontWeight: 600 }}>{label}</div>
    </div>
  );
}

// ─── Profile Page ─────────────────────────────────────────────────────────────
function ProfilePage({ user, logout, navigate, showToast, setUser }) {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ username: user?.username || "", email: user?.email || "" });
  const [pwForm, setPwForm] = useState({ oldPw: "", newPw: "", confirmPw: "" });
  const [tab, setTab] = useState("liked");
  const [myProfileLikes, setMyProfileLikes] = useState(0);
  const [myFriendCount, setMyFriendCount] = useState(0);
  const [collections, setCollections] = useState({ liked: [], favorited: [], saved: [] });
  const [loadingCollections, setLoadingCollections] = useState(true);
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingPw, setSavingPw] = useState(false);

  useEffect(() => {
    if (!user) return;
    let active = true;
    (async () => {
      const [likeCount, liked, favorited, saved, friendCount] = await Promise.all([
        db.getProfileLikeCount(user.id),
        db.getMyInteractedProducts("likes", user.id),
        db.getMyInteractedProducts("favorites", user.id),
        db.getMyInteractedProducts("saves", user.id),
        db.getFriendCount(user.id),
      ]);
      if (!active) return;
      setMyProfileLikes(likeCount);
      setCollections({ liked, favorited, saved });
      setMyFriendCount(friendCount);
      setLoadingCollections(false);
    })();
    return () => { active = false; };
  }, [user?.id]);

  if (!user) return (
    <div style={{ ...S.section, paddingTop: 40, textAlign: "center" }}>
      <div style={{ fontSize: 60, marginBottom: 16 }}>👤</div>
      <div style={S.h2}>Belum Masuk</div>
      <p style={{ ...S.subtitle, marginBottom: 24 }}>Masuk untuk lihat profil kamu</p>
      <button style={S.btnPrimary} onClick={() => navigate("login-daftar")}>Masuk / Daftar</button>
    </div>
  );

  const saveProfile = async () => {
    if (!form.username.trim() || !form.email.trim()) { showToast("Username dan email tidak boleh kosong."); return; }
    setSavingProfile(true);
    try {
      await db.updateMyProfile(user.id, { username: form.username.trim() });
      // Email changes go through Supabase Auth (may require confirmation depending on project settings).
      if (form.email.trim() !== user.email) {
        const { error } = await supabase.auth.updateUser({ email: form.email.trim() });
        if (error) throw error;
      }
      setUser({ ...user, username: form.username.trim(), email: form.email.trim() });
      showToast("Profil diperbarui! ✅");
      setEditing(false);
    } catch (err) {
      showToast(err.message || "Gagal memperbarui profil.");
    } finally {
      setSavingProfile(false);
    }
  };

  const changePw = async () => {
    if (!pwForm.oldPw || !pwForm.newPw || !pwForm.confirmPw) { showToast("Semua kolom harus diisi."); return; }
    if (pwForm.newPw !== pwForm.confirmPw) { showToast("Password baru tidak cocok."); return; }
    if (pwForm.newPw.length < 6) { showToast("Password baru minimal 6 karakter."); return; }
    setSavingPw(true);
    try {
      // Verify the old password by attempting a fresh sign-in before changing it.
      await db.signIn(user.email, pwForm.oldPw);
      await db.changePassword(pwForm.newPw);
      showToast("Password berhasil diubah! 🔐");
      setPwForm({ oldPw: "", newPw: "", confirmPw: "" });
    } catch (err) {
      showToast(err.message?.includes("Invalid login") ? "Password lama salah." : (err.message || "Gagal mengubah password."));
    } finally {
      setSavingPw(false);
    }
  };

  const isSeller = user.role === "seller";
  const tabProducts = collections[tab] || [];

  return (
    <div style={S.section}>
      <div style={{ paddingTop: 20, textAlign: "center", marginBottom: 24 }}>
        <div style={{ position: "relative", width: 80, height: 80, margin: "0 auto 12px" }}>
          <div style={{ width: 80, height: 80, borderRadius: "50%", background: "linear-gradient(135deg,#CC1818,#FF8C00)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 36, fontWeight: 900 }}>
            {user.username[0].toUpperCase()}
          </div>
          <span style={{ position: "absolute", bottom: 2, right: 2, width: 16, height: 16, borderRadius: "50%", background: "#2ECC71", border: "3px solid #0A0A0F" }} />
        </div>
        <div style={{ fontSize: 20, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
          {user.username}
          {isVerified(user) && <VerifiedBadge size={18} />}
        </div>
        <div style={{ fontSize: 12, color: "#2ECC71", marginTop: 2, fontWeight: 600 }}>🟢 Online</div>
        <div style={{ fontSize: 13, color: "#888", marginTop: 4 }}>{user.email}</div>
        {user.public_id && (
          <div style={{ display: "flex", justifyContent: "center", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
            <div
              style={{ display: "inline-flex", alignItems: "center", gap: 10, background: "#12121E", border: "1px solid #1E1E30", borderRadius: 10, padding: "6px 14px", cursor: "pointer" }}
              onClick={() => navigate("publicProfile", user.public_id)}
            >
              <span style={{ fontSize: 12, color: "#888", fontFamily: "monospace" }}>/profile/{user.public_id}</span>
              <span style={{ fontSize: 12, color: "#FF3B3B", fontWeight: 700 }}>❤️ {myProfileLikes}</span>
              <span style={{ fontSize: 12, color: "#3B9CFF", fontWeight: 700 }}>👥 {myFriendCount}</span>
            </div>
            <button
              style={{ ...S.btnSmall, display: "flex", alignItems: "center", gap: 6 }}
              onClick={() => navigate("friends")}
            >
              🔍 Cari Teman
            </button>
            <button
              style={{ ...S.btnSmall, display: "flex", alignItems: "center", gap: 6 }}
              onClick={() => shareLink({ title: user.username, text: `Lihat profil ${user.username} di Dragon Store!`, path: `/profile/${user.public_id}`, showToast })}
            >
              🔗 Bagikan
            </button>
          </div>
        )}
      </div>

      <div style={S.divider} />

      {isSeller && (
        <>
          <button style={{ ...S.btnSecondary, background: "#0A1A2A", borderColor: "#103050", color: "#3B9CFF", marginBottom: 8 }} onClick={() => navigate("seller")}>🏷️ Kelola Produk Jualan Saya</button>
          <div style={S.divider} />
        </>
      )}

      {/* Edit profile */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <div style={{ fontWeight: 700, fontSize: 15 }}>Informasi Akun</div>
          <button style={S.btnSmall} onClick={() => setEditing(!editing)}>{editing ? "Batal" : "Edit"}</button>
        </div>
        {editing ? (
          <>
            <div style={S.formGroup}><label style={S.label}>Username</label><input style={S.input} value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} /></div>
            <div style={S.formGroup}><label style={S.label}>Email</label><input style={S.input} value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
            <button style={{ ...S.btnPrimary, opacity: savingProfile ? 0.6 : 1 }} disabled={savingProfile} onClick={saveProfile}>{savingProfile ? "Menyimpan..." : "Simpan Perubahan"}</button>
          </>
        ) : (
          <div style={{ background: "#12121E", border: "1px solid #1E1E30", borderRadius: 12, overflow: "hidden" }}>
            <InfoRow label="Username" value={user.username} />
            <InfoRow label="Email" value={user.email} />
          </div>
        )}
      </div>

      <div style={S.divider} />

      {/* Liked / Favorited / Saved products */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 12 }}>Koleksi Produk Saya</div>
        <div className="ds-hide-scrollbar" style={{ display: "flex", gap: 8, marginBottom: 14, overflowX: "auto" }}>
          {[
            { id: "liked", label: `👍 Disukai (${collections.liked.length})` },
            { id: "favorited", label: `⭐ Favorit (${collections.favorited.length})` },
            { id: "saved", label: `🔖 Disimpan (${collections.saved.length})` },
          ].map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              background: tab === t.id ? "linear-gradient(135deg,#CC1818,#FF3B3B)" : "#12121E",
              color: tab === t.id ? "#fff" : "#aaa",
              border: tab === t.id ? "none" : "1px solid #1E1E30",
              borderRadius: 20, padding: "7px 14px", fontWeight: 700, fontSize: 12,
              cursor: "pointer", whiteSpace: "nowrap", flexShrink: 0
            }}>{t.label}</button>
          ))}
        </div>
        {loadingCollections ? <Spinner /> : tabProducts.length === 0 ? (
          <div style={{ ...S.emptyState, padding: "30px 0" }}>
            <div style={{ fontSize: 36, marginBottom: 8 }}>🐉</div>
            <p style={{ color: "#555", fontSize: 13 }}>
              {tab === "liked" && "Belum ada produk yang kamu sukai."}
              {tab === "favorited" && "Belum ada produk favorit."}
              {tab === "saved" && "Belum ada produk yang disimpan."}
            </p>
          </div>
        ) : (
          <div className="ds-grid">
            {tabProducts.map(p => <ProductCardSmall key={p.id} product={p} navigate={navigate} />)}
          </div>
        )}
      </div>

      <div style={S.divider} />

      {/* Change password */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 12 }}>Ganti Password</div>
        <div style={S.formGroup}><label style={S.label}>Password Lama</label><input type="password" style={S.input} value={pwForm.oldPw} onChange={e => setPwForm({ ...pwForm, oldPw: e.target.value })} /></div>
        <div style={S.formGroup}><label style={S.label}>Password Baru</label><input type="password" style={S.input} value={pwForm.newPw} onChange={e => setPwForm({ ...pwForm, newPw: e.target.value })} /></div>
        <div style={S.formGroup}><label style={S.label}>Konfirmasi Password Baru</label><input type="password" style={S.input} value={pwForm.confirmPw} onChange={e => setPwForm({ ...pwForm, confirmPw: e.target.value })} /></div>
        <button style={{ ...S.btnSecondary, opacity: savingPw ? 0.6 : 1 }} disabled={savingPw} onClick={changePw}>{savingPw ? "Menyimpan..." : "Ganti Password 🔐"}</button>
      </div>

      <div style={S.divider} />
      <button style={{ ...S.btnDanger, width: "100%", marginTop: 8 }} onClick={logout}>Keluar dari Akun</button>
    </div>
  );
}

function InfoRow({ label, value }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: "12px 16px", borderBottom: "1px solid #1A1A2E" }}>
      <span style={{ fontSize: 13, color: "#888" }}>{label}</span>
      <span style={{ fontSize: 13, fontWeight: 600 }}>{value}</span>
    </div>
  );
}

// ─── Email Verification Page ──────────────────────────────────────────────────
function VerifyEmailPage() {
  const [status, setStatus] = useState('loading');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const verifyEmail = async () => {
      try {
        // Supabase bisa kirim token via hash (#) atau query string (?), support keduanya
        const hash = new URLSearchParams(window.location.hash.substring(1));
        const query = new URLSearchParams(window.location.search);

        const accessToken = hash.get('access_token') || query.get('access_token');
        const tokenHash   = hash.get('token_hash')   || query.get('token_hash');
        const type        = hash.get('type')          || query.get('type');
        const errorDesc   = hash.get('error_description') || query.get('error_description');

        // Supabase langsung kirim error di URL
        if (errorDesc) {
          if (errorDesc.toLowerCase().includes('expired') || errorDesc.toLowerCase().includes('invalid')) {
            setStatus('expired');
          } else {
            setStatus('error');
            setMessage(errorDesc);
          }
          return;
        }

        // Kalau ada access_token di URL — session langsung aktif (Supabase auto-login)
        if (accessToken && type === 'signup') {
          const { data: sessionData } = await supabase.auth.getSession();
          if (sessionData?.session?.user) {
            setStatus('success');
            setTimeout(() => { window.location.href = '/'; }, 2000);
            return;
          }
        }

        // PKCE flow — pakai token_hash
        if (tokenHash) {
          const { data, error } = await supabase.auth.verifyOtp({
            token_hash: tokenHash,
            type: 'email',
          });
          if (error) {
            const msg = error.message?.toLowerCase();
            if (msg?.includes('expired') || msg?.includes('invalid')) {
              setStatus('expired');
            } else {
              setStatus('error');
              setMessage(error.message);
            }
            return;
          }
          if (data?.user) {
            setStatus('success');
            setTimeout(() => { window.location.href = '/'; }, 2000);
            return;
          }
        }

        // Tidak ada token sama sekali
        setStatus('error');
        setMessage('Link tidak valid. Pastikan kamu membuka link dari email verifikasi.');
      } catch (err) {
        console.error('Verification error:', err);
        setStatus('error');
        setMessage('Terjadi kesalahan saat verifikasi.');
      }
    };

    verifyEmail();
  }, []);

  const btnStyle = {
    padding: '12px 28px',
    background: 'linear-gradient(135deg,#CC1818,#FF3B3B)',
    border: 'none', borderRadius: '8px',
    color: '#fff', cursor: 'pointer',
    fontWeight: 700, fontSize: 14,
    marginTop: 8
  };

  return (
    <div style={{
      display: 'flex', justifyContent: 'center', alignItems: 'center',
      minHeight: '100vh', background: '#0a0e1a',
      color: '#fff', fontFamily: 'Arial, sans-serif', padding: '20px'
    }}>
      <div style={{
        textAlign: 'center', padding: '48px 32px',
        background: '#12121E', borderRadius: '16px',
        border: '1px solid #1E1E30', maxWidth: '420px', width: '100%'
      }}>

        {status === 'loading' && (
          <>
            <div style={{ fontSize: 56, marginBottom: 20 }}>🐉</div>
            <h2 style={{ fontSize: 22, fontWeight: 800, color: '#fff', marginBottom: 10 }}>Memverifikasi Email...</h2>
            <p style={{ fontSize: 14, color: '#666' }}>Mohon tunggu sebentar...</p>
          </>
        )}

        {status === 'success' && (
          <>
            <div style={{ fontSize: 56, marginBottom: 20 }}>✅</div>
            <h2 style={{ fontSize: 22, fontWeight: 800, color: '#7FD67F', marginBottom: 10 }}>Email Berhasil Diverifikasi!</h2>
            <p style={{ fontSize: 14, color: '#888', marginBottom: 4 }}>Akun kamu sudah aktif.</p>
            <p style={{ fontSize: 13, color: '#555' }}>Mengalihkan ke halaman utama...</p>
          </>
        )}

        {status === 'expired' && (
          <>
            <div style={{ fontSize: 56, marginBottom: 20 }}>⏰</div>
            <h2 style={{ fontSize: 22, fontWeight: 800, color: '#FF6B6B', marginBottom: 10 }}>Link Sudah Expired</h2>
            <p style={{ fontSize: 14, color: '#888', marginBottom: 24 }}>
              Link verifikasi sudah tidak berlaku.<br />Silakan daftar ulang atau minta kirim ulang email.
            </p>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap' }}>
              <button style={btnStyle} onClick={() => window.location.href = '/masuk'}>Daftar Ulang</button>
              <button style={{ ...btnStyle, background: '#1E1E30', border: '1px solid #333' }}
                onClick={() => window.location.href = '/'}>Ke Home</button>
            </div>
          </>
        )}

        {status === 'error' && (
          <>
            <div style={{ fontSize: 56, marginBottom: 20 }}>❌</div>
            <h2 style={{ fontSize: 22, fontWeight: 800, color: '#FF6B6B', marginBottom: 10 }}>Verifikasi Gagal</h2>
            <p style={{ fontSize: 14, color: '#888', marginBottom: 24 }}>{message}</p>
            <button style={btnStyle} onClick={() => window.location.href = '/'}>Kembali ke Home</button>
          </>
        )}

      </div>
    </div>
  );
}

// ─── Login / Daftar Page ──────────────────────────────────────────────────────
function LoginPage({ login, navigate, showToast }) {
  const [tab, setTab] = useState("login");
  const [form, setForm] = useState({ username: "", email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [nextAvailable, setNextAvailable] = useState(getNextAvailableSignupTime());
  const [registered, setRegistered] = useState(false); // setelah daftar sukses
  const [resendLoading, setResendLoading] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0); // countdown detik

  // Check rate limit every second (for countdown)
  useEffect(() => {
    const interval = setInterval(() => {
      setNextAvailable(getNextAvailableSignupTime());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Countdown resend button
  useEffect(() => {
    if (resendCooldown <= 0) return;
    const t = setTimeout(() => setResendCooldown(c => c - 1), 1000);
    return () => clearTimeout(t);
  }, [resendCooldown]);

  const doLogin = async () => {
    if (!form.email.trim() || !form.password.trim()) { showToast("Email dan password wajib diisi."); return; }
    setLoading(true);
    try {
      await db.signIn(form.email.trim(), form.password);
      const profile = await db.getMyProfile();
      if (!profile) { showToast("Gagal memuat profil. Coba lagi."); return; }
      login(profile);
    } catch (err) {
      showToast(err.message?.includes("Invalid login") ? "Email atau password salah." : (err.message || "Gagal masuk."));
    } finally {
      setLoading(false);
    }
  };

  const doRegister = async () => {
    if (!form.username.trim() || !form.email.trim() || !form.password.trim()) { showToast("Semua kolom wajib diisi."); return; }
    if (form.password.length < 6) { showToast("Password minimal 6 karakter."); return; }

    // CHECK RATE LIMIT LOKAL
    const next = getNextAvailableSignupTime();
    if (next) {
      const h = String(next.getHours()).padStart(2, '0');
      const m = String(next.getMinutes()).padStart(2, '0');
      showToast(`⏰ Server Kami Sedang Sibuk, Tunggu di Jam ${h}:${m}`);
      return;
    }

    setLoading(true);
    try {
      await db.signUp(form.username.trim(), form.email.trim(), form.password);
      localStorage.setItem('lastSignupAttempt', Date.now().toString());
      setRegistered(true); // tampilkan layar "cek email"
    } catch (err) {
      // Rate limit dari server
      if (err?.status === 429 || err?.message === 'RATE_LIMIT' || err?.message?.toLowerCase().includes('rate')) {
        localStorage.setItem('lastSignupAttempt', Date.now().toString());
        const nextHour = new Date();
        nextHour.setHours(nextHour.getHours() + 1, 0, 0, 0);
        const h = String(nextHour.getHours()).padStart(2, '0');
        const m = String(nextHour.getMinutes()).padStart(2, '0');
        showToast(`⏰ Server Kami Sedang Sibuk, Tunggu di Jam ${h}:${m}`);
        return;
      }
      showToast(err.message?.includes("already registered") || err.message?.includes("sudah terdaftar")
        ? "Email sudah terdaftar." : (err.message || "Gagal daftar."));
    } finally {
      setLoading(false);
    }
  };

  const doResend = async () => {
    if (!form.email.trim()) { showToast("Masukkan email kamu dulu."); return; }
    setResendLoading(true);
    try {
      await db.resendVerificationEmail(form.email.trim());
      showToast("📧 Email verifikasi dikirim ulang!");
      setResendCooldown(60); // cooldown 60 detik
    } catch (err) {
      if (err?.status === 429 || err?.message === 'RATE_LIMIT') {
        const nextHour = new Date();
        nextHour.setHours(nextHour.getHours() + 1, 0, 0, 0);
        const h = String(nextHour.getHours()).padStart(2, '0');
        const m = String(nextHour.getMinutes()).padStart(2, '0');
        showToast(`⏰ Server Sibuk, Coba lagi jam ${h}:${m}`);
      } else {
        showToast(err.message || "Gagal kirim ulang email.");
      }
    } finally {
      setResendLoading(false);
    }
  };

  // ── Layar sukses daftar: cek email ─────────────────────────────────────────
  if (registered) {
    return (
      <div style={{ ...S.section, paddingTop: 60, textAlign: "center" }}>
        <div style={{ fontSize: 64, marginBottom: 20 }}>📧</div>
        <div style={{ ...S.h1, marginBottom: 10 }}>Cek Email Kamu!</div>
        <p style={{ ...S.subtitle, marginBottom: 8, lineHeight: 1.7 }}>
          Kami sudah kirim link verifikasi ke<br />
          <strong style={{ color: "#FF3B3B" }}>{form.email}</strong>
        </p>
        <p style={{ ...S.subtitle, marginBottom: 30, fontSize: 12 }}>
          Klik link di email tersebut untuk mengaktifkan akun kamu.
        </p>
        <div style={{ background: "#12121E", borderRadius: 12, padding: 20, marginBottom: 20, border: "1px solid #1E1E30" }}>
          <p style={{ fontSize: 12, color: "#666", marginBottom: 12 }}>Email tidak masuk? Cek folder spam, atau kirim ulang:</p>
          <button
            style={{ ...S.btnSecondary, opacity: (resendLoading || resendCooldown > 0) ? 0.6 : 1 }}
            disabled={resendLoading || resendCooldown > 0}
            onClick={doResend}
          >
            {resendLoading ? "Mengirim..." : resendCooldown > 0 ? `Kirim Ulang (${resendCooldown}s)` : "📨 Kirim Ulang Email"}
          </button>
        </div>
        <button style={{ ...S.btnPrimary }} onClick={() => { setRegistered(false); setTab("login"); }}>
          Sudah Verifikasi? Masuk 🔥
        </button>
      </div>
    );
  }

  return (
    <div style={{ ...S.section, paddingTop: 40 }}>
      <div style={{ textAlign: "center", marginBottom: 32 }}>
        <div style={{ fontSize: 50, marginBottom: 12 }}>🐉</div>
        <div style={S.h1}>{STORE_NAME}</div>
        <p style={S.subtitle}>Masuk untuk pengalaman belanja terbaik</p>
      </div>

      {/* Tab */}
      <div style={{ display: "flex", background: "#12121E", borderRadius: 12, padding: 4, marginBottom: 24 }}>
        {["login", "daftar"].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            flex: 1, border: "none", cursor: "pointer", borderRadius: 10, padding: "11px 0",
            background: tab === t ? "linear-gradient(135deg,#CC1818,#FF3B3B)" : "transparent",
            color: tab === t ? "#fff" : "#888", fontWeight: 700, fontSize: 14, transition: "all 0.2s"
          }}>{t === "login" ? "Masuk" : "Daftar"}</button>
        ))}
      </div>

      {tab === "daftar" && (
        <div style={S.formGroup}><label style={S.label}>Username</label><input style={S.input} placeholder="Nama pengguna" value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} /></div>
      )}
      <div style={S.formGroup}><label style={S.label}>Email</label><input type="email" style={S.input} placeholder="email@kamu.com" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
      <div style={S.formGroup}><label style={S.label}>Password</label><input type="password" style={S.input} placeholder="••••••••" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} onKeyDown={e => e.key === "Enter" && (tab === "login" ? doLogin() : doRegister())} /></div>

      {/* Rate limit warning */}
      {tab === "daftar" && nextAvailable && (
        <div style={{
          padding: '14px', background: '#FF6B6B22', border: '1px solid #FF6B6B',
          borderRadius: '10px', marginBottom: '16px', color: '#FF6B6B',
          fontSize: 14, fontWeight: 600, textAlign: 'center', lineHeight: 1.6
        }}>
          ⏰ Server Kami Sedang Sibuk<br />
          <span style={{ fontSize: 18, fontWeight: 800 }}>
            Tunggu di Jam {String(nextAvailable.getHours()).padStart(2, '0')}:{String(nextAvailable.getMinutes()).padStart(2, '0')}
          </span>
        </div>
      )}

      <button
        style={{ ...S.btnPrimary, marginTop: 8, opacity: (loading || (tab === "daftar" && nextAvailable)) ? 0.6 : 1 }}
        disabled={loading || (tab === "daftar" && !!nextAvailable)}
        onClick={tab === "login" ? doLogin : doRegister}
      >
        {loading ? "Memproses..." : (tab === "daftar" && nextAvailable ? "⏳ Tunggu..." : (tab === "login" ? "Masuk 🔥" : "Daftar Sekarang 🐉"))}
      </button>

      <p style={{ textAlign: "center", marginTop: 20, fontSize: 13, color: "#888" }}>
        {tab === "login" ? "Belum punya akun? " : "Sudah punya akun? "}
        <span style={{ color: "#FF3B3B", cursor: "pointer", fontWeight: 700 }} onClick={() => setTab(tab === "login" ? "daftar" : "login")}>
          {tab === "login" ? "Daftar" : "Masuk"}
        </span>
      </p>
    </div>
  );
}

// ─── Detail Page ──────────────────────────────────────────────────────────────
function DetailPage({ navigate, user, showToast, requireLogin, isOwner, isSeller }) {
  const { id: productId } = useParams();
  const [product, setProduct] = useState(undefined); // undefined = loading, null = not found
  const [liked, setLiked] = useState(false);
  const [favorited, setFavorited] = useState(false);
  const [saved, setSaved] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [favCount, setFavCount] = useState(0);
  const [saveCount, setSaveCount] = useState(0);
  const [comments, setComments] = useState([]);
  const [imgIdx, setImgIdx] = useState(0);
  const [commentText, setCommentText] = useState("");
  const [posting, setPosting] = useState(false);

  const loadInteractions = async (prodId) => {
    const [l, f, s, lc, fc, sc] = await Promise.all([
      db.isInteracted("likes", prodId, user?.id),
      db.isInteracted("favorites", prodId, user?.id),
      db.isInteracted("saves", prodId, user?.id),
      db.getInteractionCount("likes", prodId),
      db.getInteractionCount("favorites", prodId),
      db.getInteractionCount("saves", prodId),
    ]);
    setLiked(l); setFavorited(f); setSaved(s); setLikeCount(lc); setFavCount(fc); setSaveCount(sc);
  };

  const loadComments = async (prodId) => {
    setComments(await db.getComments(prodId));
  };

  useEffect(() => {
    let active = true;
    (async () => {
      const p = await db.getProductById(productId);
      if (!active) return;
      setProduct(p || null);
      if (p) { await loadInteractions(p.id); await loadComments(p.id); }
    })();
    return () => { active = false; };
  }, [productId, user?.id]);

  if (product === undefined) return <Spinner />;
  if (product === null) return <div style={{ ...S.emptyState, paddingTop: 60 }}><div style={{ fontSize: 50 }}>😕</div><p>Produk tidak ditemukan.</p><button style={{ ...S.btnSecondary, marginTop: 16 }} onClick={() => navigate("hub")}>Kembali</button></div>;

  const openWA = () => {
    const phone = product.phone?.replace(/\D/g, "");
    if (!phone) { showToast("Nomor penjual tidak tersedia."); return; }
    const msg = encodeURIComponent(`Halo, saya tertarik dengan produk *${product.name}* (ID: ${product.id}) di Dragon Store ID. Apakah masih tersedia?`);
    window.open(`https://wa.me/${phone}?text=${msg}`, "_blank");
  };

  const doToggle = async (kind) => {
    if (!requireLogin()) return;
    const justAdded = await db.toggleInteraction(kind, product.id, user.id);
    if (kind === "likes" && justAdded) {
      // Fire-and-forget: let friends know. Never let a hiccup here block the
      // like action itself from completing successfully in the UI.
      db.notifyFriendsOfProductLike(user.id, product.id, product.name).catch(() => {});
    }
    loadInteractions(product.id);
  };

  const postComment = async () => {
    if (!requireLogin()) return;
    if (!commentText.trim()) { showToast("Komentar tidak boleh kosong."); return; }
    setPosting(true);
    try {
      await db.postComment(product.id, user.id, commentText.trim());
      if (!isOwner) {
        const owner = await db.getOwnerProfile();
        if (owner) await db.addNotification(owner.id, "comment", `${user.username} mengomentari produk "${product.name}".`, `/produk/${product.id}`);
      }
      setCommentText("");
      loadComments(product.id);
    } catch (err) {
      showToast(err.message || "Gagal mengirim komentar.");
    } finally {
      setPosting(false);
    }
  };

  const canDeleteComment = (c) => isOwner || c.userId === user?.id || (isSeller && product?.seller_id === user?.id);

  const deleteComment = async (comment) => {
    if (!canDeleteComment(comment)) return;
    try {
      await db.deleteComment(comment.id);
      loadComments(product.id);
    } catch (err) {
      showToast(err.message || "Gagal menghapus komentar.");
    }
  };

  const likeComment = async (comment) => {
    if (!requireLogin()) return;
    const justLiked = await db.toggleCommentLike(comment.id, user.id);
    if (justLiked && comment.userId !== user.id) {
      await db.addNotification(comment.userId, "comment-like", `${user.username} menyukai komentar kamu di produk "${product.name}".`, `/produk/${product.id}`);
    }
    loadComments(product.id);
  };

  return (
    <div>
      {/* Back button */}
      <div style={{ padding: "16px 16px 0" }}>
        <button style={{ ...S.btnSmall, marginBottom: 12 }} onClick={() => navigate("hub")}>← Kembali</button>
      </div>

      <div className="ds-detail-layout">
        <div className="ds-detail-media">
          {/* Image gallery */}
          <div style={{ position: "relative" }}>
            <ImgBox src={product.images?.[imgIdx]} style={{ width: "100%", height: 280, objectFit: "cover", borderRadius: 14 }} />
            {product.images?.length > 1 && (
              <div style={{ position: "absolute", bottom: 12, left: "50%", transform: "translateX(-50%)", display: "flex", gap: 6 }}>
                {product.images.map((_, i) => (
                  <div key={i} onClick={() => setImgIdx(i)} style={{ width: i === imgIdx ? 20 : 8, height: 8, borderRadius: 4, background: i === imgIdx ? "#FF3B3B" : "#fff8", cursor: "pointer", transition: "all 0.2s" }} />
                ))}
              </div>
            )}
          </div>

          {/* Thumbnail strip */}
          {product.images?.length > 1 && (
            <div className="ds-hide-scrollbar" style={{ display: "flex", gap: 8, padding: "12px 0 0", overflowX: "auto", scrollbarWidth: "none" }}>
              {product.images.map((img, i) => (
                <div key={i} onClick={() => setImgIdx(i)} style={{ width: 60, height: 60, flexShrink: 0, borderRadius: 10, overflow: "hidden", border: `2px solid ${i === imgIdx ? "#FF3B3B" : "#1E1E30"}`, cursor: "pointer" }}>
                  <ImgBox src={img} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="ds-detail-info" style={S.section}>
          <div style={{ paddingTop: 16 }}>
            <div style={{ fontSize: 11, color: "#FF6B35", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 8 }}>{product.category}</div>
            <div style={{ fontSize: 22, fontWeight: 900, color: "#F0F0FF", marginBottom: 12 }}>{product.name}</div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
              <div style={{ background: "#12121E", border: "1px solid #1E1E30", borderRadius: 10, padding: "8px 14px", display: "inline-flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 11, color: "#888" }}>Product ID</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: "#FF6B35", fontFamily: "monospace" }}>{product.id}</span>
              </div>
              <button
                style={{ ...S.btnSmall, display: "flex", alignItems: "center", gap: 6 }}
                onClick={() => shareLink({ title: product.name, text: `Lihat produk "${product.name}" di Dragon Store!`, path: `/produk/${product.id}`, showToast })}
              >
                🔗 Bagikan
              </button>
            </div>

            {/* Like / Favorite / Save */}
            <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
              <button style={S.interactBtn(liked, "#FF3B3B")} onClick={() => doToggle("likes")}>
                👍 Suka {likeCount > 0 && `· ${likeCount}`}
              </button>
              <button style={S.interactBtn(favorited, "#FFD700")} onClick={() => doToggle("favorites")}>
                ⭐ Favorit {favCount > 0 && `· ${favCount}`}
              </button>
              <button style={S.interactBtn(saved, "#3B9CFF")} onClick={() => doToggle("saves")}>
                🔖 Simpan {saveCount > 0 && `· ${saveCount}`}
              </button>
            </div>

            {product.description && (
              <>
                <div style={S.divider} />
                <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 8 }}>Deskripsi</div>
                <p style={{ fontSize: 14, color: "#A0A0B0", lineHeight: 1.7, whiteSpace: "pre-wrap" }}>{product.description}</p>
              </>
            )}

            <div style={S.divider} />
            <button style={S.btnWA} onClick={openWA}>
              <span style={{ fontSize: 20 }}>💬</span>
              Hubungi Penjual via WhatsApp
            </button>
          </div>
        </div>
      </div>

      {/* Comments */}
      <div style={{ ...S.section, marginTop: 24, paddingBottom: 24 }}>
        <div style={S.divider} />
        <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 14 }}>💬 Komentar ({comments.length})</div>

        <div style={{ display: "flex", gap: 8, marginBottom: 18 }}>
          <input
            style={{ ...S.input, flex: 1 }}
            placeholder={user ? "Tulis komentar..." : "Masuk untuk berkomentar"}
            value={commentText}
            onChange={e => setCommentText(e.target.value)}
            onKeyDown={e => e.key === "Enter" && !posting && postComment()}
          />
          <button style={{ ...S.btnPrimary, width: "auto", padding: "13px 20px", opacity: posting ? 0.6 : 1 }} disabled={posting} onClick={postComment}>{posting ? "..." : "Kirim"}</button>
        </div>

        {comments.length === 0 ? (
          <p style={{ color: "#555", fontSize: 13, textAlign: "center", padding: "16px 0" }}>Belum ada komentar. Jadi yang pertama!</p>
        ) : (
          comments.map(c => {
            const cLikes = c.likedBy?.length || 0;
            const cLikedByMe = user && c.likedBy?.includes(user.id);
            return (
              <div key={c.id} style={S.commentBox}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6, cursor: c.userPublicId ? "pointer" : "default" }} onClick={() => {
                    if (c.userPublicId) navigate("publicProfile", c.userPublicId);
                  }}>
                    <div style={{ width: 28, height: 28, borderRadius: "50%", background: "linear-gradient(135deg,#CC1818,#FF8C00)", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 13, flexShrink: 0 }}>
                      {c.username[0].toUpperCase()}
                    </div>
                    <span style={{ fontWeight: 700, fontSize: 13, display: "flex", alignItems: "center", gap: 4 }}>
                      {c.username}
                      {isVerified({ role: c.userRole, verified: c.userVerified }) && <VerifiedBadge size={12} />}
                    </span>
                    <span style={{ fontSize: 11, color: "#555" }}>{new Date(c.createdAt).toLocaleDateString("id-ID", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</span>
                  </div>
                  {canDeleteComment(c) && (
                    <button style={{ background: "none", border: "none", color: "#555", cursor: "pointer", fontSize: 16, padding: 2 }} onClick={() => deleteComment(c)} title="Hapus komentar">🗑️</button>
                  )}
                </div>
                <p style={{ fontSize: 14, color: "#D0D0E0", marginLeft: 36, marginBottom: 8, whiteSpace: "pre-wrap" }}>{c.text}</p>
                <div style={{ marginLeft: 36 }}>
                  <button
                    style={{ ...S.interactBtn(cLikedByMe, "#FF3B3B"), flex: "none", padding: "5px 12px", fontSize: 12 }}
                    onClick={() => likeComment(c)}
                    title="Sukai komentar ini"
                  >
                    ❤️ {cLikes > 0 ? cLikes : "Suka"}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

// ─── Notifications Page ───────────────────────────────────────────────────────
function NotificationsPage({ user, navigate, onRead }) {
  const [notifs, setNotifs] = useState(null);

  useEffect(() => {
    let active = true;
    (async () => {
      const list = await db.getMyNotifications(user.id);
      if (active) setNotifs(list);
      await db.markAllNotificationsRead(user.id);
      onRead?.();
    })();
    return () => { active = false; };
  }, []);

  const iconFor = (type) => ({
    comment: "💬",
    "comment-like": "❤️",
    "profile-like": "👤",
    update: "📢",
    "new-product": "🆕",
    "admin-broadcast": "📣",
    "friend-like-product": "👥",
  }[type] || "🔔");

  const goTo = (n) => {
    if (n.link?.startsWith("/produk/")) navigate("detail", n.link.replace("/produk/", ""));
    else if (n.link?.startsWith("/profile/")) navigate("publicProfile", n.link.replace("/profile/", ""));
  };

  if (notifs === null) return <Spinner />;

  return (
    <div style={S.section}>
      <div style={{ paddingTop: 20, marginBottom: 16 }}>
        <div style={S.h1}>Notifikasi</div>
        <p style={S.subtitle}>Update terbaru buat kamu</p>
      </div>
      <div style={S.divider} />

      {notifs.length === 0 ? (
        <div style={{ ...S.emptyState, padding: "40px 0" }}>
          <div style={{ fontSize: 46, marginBottom: 12 }}>🔔</div>
          <p style={{ color: "#555" }}>Belum ada notifikasi.</p>
        </div>
      ) : (
        notifs.map(n => (
          <div
            key={n.id}
            onClick={() => goTo(n)}
            style={{ background: "#12121E", border: "1px solid #1E1E30", borderRadius: 12, padding: "12px 14px", marginBottom: 10, display: "flex", gap: 12, alignItems: "flex-start", cursor: n.link ? "pointer" : "default" }}
          >
            <span style={{ fontSize: 22 }}>{iconFor(n.type)}</span>
            <div style={{ flex: 1 }}>
              <p style={{ fontSize: 13, color: "#E8E8F0", marginBottom: 4 }}>{n.message}</p>
              <span style={{ fontSize: 11, color: "#555" }}>{new Date(n.createdAt).toLocaleDateString("id-ID", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</span>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

// ─── Public Profile Page ──────────────────────────────────────────────────────
function PublicProfilePage({ navigate, currentUser, showToast, requireLogin }) {
  const { pid } = useParams();
  const [profileUser, setProfileUser] = useState(undefined); // undefined = loading, null = not found
  const [likeCount, setLikeCount] = useState(0);
  const [likedByMe, setLikedByMe] = useState(false);
  const [likedProducts, setLikedProducts] = useState([]);
  const [friendCount, setFriendCount] = useState(0);
  const [isMyFriend, setIsMyFriend] = useState(false); // whether currentUser has this profile in their (private) friend list
  const [friendBusy, setFriendBusy] = useState(false);

  const loadProfileLikes = async (profileId) => {
    const [count, mine] = await Promise.all([
      db.getProfileLikeCount(profileId),
      currentUser ? db.isProfileLiked(profileId, currentUser.id) : Promise.resolve(false),
    ]);
    setLikeCount(count);
    setLikedByMe(mine);
  };

  useEffect(() => {
    let active = true;
    (async () => {
      const p = await db.getProfileByPublicId(pid);
      if (!active) return;
      setProfileUser(p || null);
      if (p) {
        await loadProfileLikes(p.id);
        const liked = await db.getMyInteractedProducts("likes", p.id);
        if (active) setLikedProducts(liked.slice(0, 6));
        const count = await db.getFriendCount(p.id);
        if (active) setFriendCount(count);
        if (currentUser) {
          const myFriendIds = await db.getMyFriendIds(currentUser.id);
          if (active) setIsMyFriend(myFriendIds.includes(p.id));
        }
      }
    })();
    return () => { active = false; };
  }, [pid, currentUser?.id]);

  if (profileUser === undefined) return <Spinner />;

  if (!profileUser) {
    return (
      <div style={{ ...S.emptyState, paddingTop: 60 }}>
        <div style={{ fontSize: 50 }}>😕</div>
        <p>Profil tidak ditemukan.</p>
        <button style={{ ...S.btnSecondary, marginTop: 16 }} onClick={() => navigate("hub")}>Kembali</button>
      </div>
    );
  }

  const isMe = currentUser?.id === profileUser.id;

  const toggleLike = async () => {
    if (!requireLogin()) return;
    if (isMe) { showToast("Tidak bisa menyukai profil sendiri."); return; }
    const justLiked = await db.toggleProfileLike(profileUser.id, currentUser.id);
    if (justLiked) {
      await db.addNotification(profileUser.id, "profile-like", `${currentUser.username} menyukai profil kamu.`, `/profile/${currentUser.public_id || ""}`);
    }
    loadProfileLikes(profileUser.id);
  };

  const toggleFriend = async () => {
    if (!requireLogin()) return;
    if (isMe) { showToast("Tidak bisa menambahkan diri sendiri sebagai teman."); return; }
    setFriendBusy(true);
    try {
      if (isMyFriend) {
        await db.removeFriend(currentUser.id, profileUser.id);
        setIsMyFriend(false);
        showToast("Dihapus dari daftar teman.");
      } else {
        await db.addFriend(currentUser.id, profileUser.id);
        setIsMyFriend(true);
        showToast("Ditambahkan ke daftar teman! 🐉");
      }
    } catch (err) {
      showToast(err.message || "Gagal mengubah status teman.");
    } finally {
      setFriendBusy(false);
    }
  };

  return (
    <div style={S.section}>
      <div style={{ paddingTop: 24, textAlign: "center", marginBottom: 20 }}>
        <div style={{ position: "relative", width: 84, height: 84, margin: "0 auto 12px" }}>
          <div style={{ width: 84, height: 84, borderRadius: "50%", background: "linear-gradient(135deg,#CC1818,#FF8C00)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 38, fontWeight: 900 }}>
            {profileUser.username[0].toUpperCase()}
          </div>
          <span style={{
            position: "absolute", bottom: 2, right: 2, width: 18, height: 18, borderRadius: "50%",
            background: db.isOnline(profileUser.last_seen) ? "#2ECC71" : "#555",
            border: "3px solid #0A0A0F",
          }} />
        </div>
        <div style={{ fontSize: 20, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
          {profileUser.username}
          {isVerified(profileUser) && <VerifiedBadge size={18} />}
        </div>
        <div style={{ fontSize: 12, color: db.isOnline(profileUser.last_seen) ? "#2ECC71" : "#666", marginTop: 4, fontWeight: 600 }}>
          {db.isOnline(profileUser.last_seen) ? "🟢 Online" : "⚪ Offline"}
        </div>
        <div style={{ fontSize: 12, color: "#555", marginTop: 4, fontFamily: "monospace" }}>/profile/{pid}</div>
        <div style={{ fontSize: 13, color: "#888", marginTop: 6 }}>👥 <strong style={{ color: "#D0D0E0" }}>{friendCount}</strong> Teman</div>

        <div style={{ display: "flex", justifyContent: "center", gap: 10, marginTop: 16 }}>
          <button
            style={{ ...S.interactBtn(likedByMe, "#FF3B3B"), flex: "none", padding: "10px 20px" }}
            onClick={toggleLike}
            disabled={isMe}
            title={isMe ? "Tidak bisa menyukai profil sendiri" : "Sukai profil ini"}
          >
            ❤️ {likedByMe ? "Disukai" : "Suka"} · {likeCount}
          </button>
          {!isMe && (
            <button
              style={{ ...S.interactBtn(isMyFriend, "#3B9CFF"), flex: "none", padding: "10px 20px", opacity: friendBusy ? 0.6 : 1 }}
              onClick={toggleFriend}
              disabled={friendBusy}
              title={isMyFriend ? "Hapus dari daftar teman" : "Tambahkan sebagai teman"}
            >
              {isMyFriend ? "✓ Berteman" : "+ Tambah Teman"}
            </button>
          )}
          <button
            style={{ ...S.btnSmall, display: "flex", alignItems: "center", gap: 6 }}
            onClick={() => shareLink({ title: profileUser.username, text: `Lihat profil ${profileUser.username} di Dragon Store!`, path: `/profile/${pid}`, showToast })}
          >
            🔗 Bagikan
          </button>
        </div>
      </div>

      <div style={S.divider} />

      <div style={{ marginBottom: 12 }}>
        <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 12 }}>Produk yang Disukai</div>
        {likedProducts.length === 0 ? (
          <p style={{ color: "#555", fontSize: 13, textAlign: "center", padding: "20px 0" }}>Belum menyukai produk apa pun.</p>
        ) : (
          <div className="ds-grid">
            {likedProducts.map(p => <ProductCardSmall key={p.id} product={p} navigate={navigate} />)}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Friends Search Page ───────────────────────────────────────────────────────
function FriendsSearchPage({ user, showToast, navigate, requireLogin }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState(null); // null = no search performed yet
  const [searching, setSearching] = useState(false);
  const [myFriendIds, setMyFriendIds] = useState([]);
  const [busyId, setBusyId] = useState(null);

  useEffect(() => {
    if (user) db.getMyFriendIds(user.id).then(setMyFriendIds);
  }, [user?.id]);

  const doSearch = async () => {
    if (!query.trim()) { setResults([]); return; }
    setSearching(true);
    try {
      const found = await db.searchProfiles(query, user?.id);
      setResults(found);
    } catch (err) {
      showToast(err.message || "Gagal mencari.");
    } finally {
      setSearching(false);
    }
  };

  const toggleFriend = async (target) => {
    if (!requireLogin()) return;
    setBusyId(target.id);
    try {
      if (myFriendIds.includes(target.id)) {
        await db.removeFriend(user.id, target.id);
        setMyFriendIds(myFriendIds.filter(id => id !== target.id));
        showToast("Dihapus dari daftar teman.");
      } else {
        await db.addFriend(user.id, target.id);
        setMyFriendIds([...myFriendIds, target.id]);
        showToast("Ditambahkan ke daftar teman! 🐉");
      }
    } catch (err) {
      showToast(err.message || "Gagal mengubah status teman.");
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div style={S.section}>
      <div style={{ paddingTop: 20, marginBottom: 16 }}>
        <div style={S.h1}>Cari Teman</div>
        <p style={S.subtitle}>Cari berdasarkan username. Jumlah temanmu tampil publik di profil, tapi daftar siapa-siapanya tetap privat — cuma kamu yang bisa lihat.</p>
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        <input
          style={{ ...S.input, flex: 1 }}
          placeholder="Cari username..."
          value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={e => { if (e.key === "Enter") doSearch(); }}
        />
        <button style={S.btnPrimary} onClick={doSearch} disabled={searching}>{searching ? "..." : "🔍 Cari"}</button>
      </div>

      {results === null ? (
        <div style={{ ...S.emptyState, padding: "40px 0" }}>
          <div style={{ fontSize: 46, marginBottom: 12 }}>🔍</div>
          <p style={{ color: "#555" }}>Cari teman baru lewat username mereka.</p>
        </div>
      ) : results.length === 0 ? (
        <div style={{ ...S.emptyState, padding: "40px 0" }}>
          <div style={{ fontSize: 46, marginBottom: 12 }}>😕</div>
          <p style={{ color: "#555" }}>Tidak ada user dengan username itu.</p>
        </div>
      ) : (
        results.map(r => {
          const isFriend = myFriendIds.includes(r.id);
          const isMe = user?.id === r.id;
          return (
            <div key={r.id} style={{ background: "#12121E", border: "1px solid #1E1E30", borderRadius: 14, padding: 14, marginBottom: 10, display: "flex", gap: 12, alignItems: "center" }}>
              <div
                style={{ width: 40, height: 40, borderRadius: "50%", background: "linear-gradient(135deg,#CC1818,#FF8C00)", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 16, flexShrink: 0, cursor: "pointer" }}
                onClick={() => navigate("publicProfile", r.public_id)}
              >
                {r.username[0].toUpperCase()}
              </div>
              <div style={{ flex: 1, minWidth: 0, cursor: "pointer" }} onClick={() => navigate("publicProfile", r.public_id)}>
                <div style={{ fontWeight: 700, fontSize: 14, color: "#F0F0FF", display: "flex", alignItems: "center", gap: 4 }}>
                  {r.username}
                  {isVerified(r) && <VerifiedBadge size={13} />}
                </div>
                <div style={{ fontSize: 11, color: "#666", fontFamily: "monospace" }}>/profile/{r.public_id}</div>
              </div>
              {!isMe && (
                <button
                  style={{ ...S.interactBtn(isFriend, "#3B9CFF"), flex: "none", padding: "8px 14px", fontSize: 12, opacity: busyId === r.id ? 0.6 : 1 }}
                  disabled={busyId === r.id}
                  onClick={() => toggleFriend(r)}
                >
                  {busyId === r.id ? "..." : (isFriend ? "✓ Berteman" : "+ Tambah")}
                </button>
              )}
            </div>
          );
        })
      )}
    </div>
  );
}

// ─── Owner Page ───────────────────────────────────────────────────────────────
function OwnerPage({ showToast, navigate }) {
  const [tab, setTab] = useState("products");
  const [products, setProducts] = useState(null);
  const [categories, setCategories] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [newCat, setNewCat] = useState("");
  const [saving, setSaving] = useState(false);

  // Send-notification tab state
  const [notifTarget, setNotifTarget] = useState("global"); // "global" | "selected"
  const [notifTitle, setNotifTitle] = useState("");
  const [notifDesc, setNotifDesc] = useState("");
  const [notifIds, setNotifIds] = useState("");
  const [sendingNotif, setSendingNotif] = useState(false);

  // Members tab state (ban/unban)
  const [members, setMembers] = useState(null);
  const [banTargetId, setBanTargetId] = useState(null); // public_id currently being banned via the modal-like form
  const [banDuration, setBanDuration] = useState("24"); // hours, "" = permanent
  const [banReason, setBanReason] = useState("");
  const [banBusy, setBanBusy] = useState(false);
  const [sellerBusyId, setSellerBusyId] = useState(null); // public_id currently being promoted/demoted
  const [verifiedBusyId, setVerifiedBusyId] = useState(null); // public_id currently having its checkmark toggled

  const loadMembers = async () => setMembers(await db.getAllProfilesWithBanStatus());

  const refresh = async () => {
    const [prods, cats] = await Promise.all([db.getProductsWithSellerInfo(), db.getCategories()]);
    setProducts(prods);
    setCategories(cats);
  };

  useEffect(() => { refresh(); }, []);
  useEffect(() => { if (tab === "members" && members === null) loadMembers(); }, [tab]);

  if (products === null) return <Spinner />;

  const handleDeleteProduct = async (id) => {
    try {
      await db.deleteProduct(id);
      setProducts(products.filter(p => p.id !== id));
      showToast("Produk dihapus.");
    } catch (err) {
      showToast(err.message || "Gagal menghapus produk.");
    }
  };

  const handleAddCategory = async () => {
    if (!newCat.trim()) return;
    if (categories.includes(newCat.trim())) { showToast("Kategori sudah ada."); return; }
    try {
      await db.addCategory(newCat.trim());
      setCategories([...categories, newCat.trim()]);
      setNewCat("");
      showToast("Kategori ditambahkan! ✅");
    } catch (err) {
      showToast(err.message || "Gagal menambah kategori.");
    }
  };

  const handleDeleteCategory = async (c) => {
    try {
      await db.deleteCategory(c);
      setCategories(categories.filter(x => x !== c));
      showToast("Kategori dihapus.");
    } catch (err) {
      showToast(err.message || "Gagal menghapus kategori.");
    }
  };

  const handleSendNotification = async () => {
    if (!notifTitle.trim() || !notifDesc.trim()) { showToast("Judul dan deskripsi wajib diisi."); return; }
    setSendingNotif(true);
    try {
      const message = `${notifTitle.trim()}: ${notifDesc.trim()}`;
      if (notifTarget === "global") {
        const allIds = await db.getAllProfileIds();
        if (!allIds.length) { showToast("Belum ada member terdaftar."); return; }
        await db.sendNotificationToMany(allIds, "admin-broadcast", message, null);
        showToast(`Notifikasi terkirim ke ${allIds.length} member! 📣`);
      } else {
        const publicIds = notifIds.split(/[,\s]+/).map(s => s.trim()).filter(Boolean);
        if (!publicIds.length) { showToast("Masukkan minimal satu Public ID."); return; }
        const profiles = await db.getProfilesByPublicIds(publicIds);
        if (!profiles.length) { showToast("Tidak ada akun yang cocok dengan ID tersebut."); return; }
        await db.sendNotificationToMany(profiles.map(p => p.id), "admin-broadcast", message, null);
        const notFound = publicIds.filter(pid => !profiles.some(p => p.public_id === pid));
        showToast(`Terkirim ke ${profiles.length} akun.${notFound.length ? ` ID tidak ditemukan: ${notFound.join(", ")}` : ""}`);
      }
      setNotifTitle("");
      setNotifDesc("");
      setNotifIds("");
    } catch (err) {
      showToast(err.message || "Gagal mengirim notifikasi.");
    } finally {
      setSendingNotif(false);
    }
  };

  const handleConfirmBan = async (publicId) => {
    setBanBusy(true);
    try {
      const hours = banDuration.trim() === "" ? null : parseFloat(banDuration);
      if (hours !== null && (isNaN(hours) || hours <= 0)) { showToast("Durasi tidak valid."); setBanBusy(false); return; }
      await db.banUser(publicId, hours, banReason.trim());
      showToast(hours === null ? "Akun dibanned permanen." : `Akun dibanned selama ${hours} jam.`);
      setBanTargetId(null);
      setBanDuration("24");
      setBanReason("");
      await loadMembers();
    } catch (err) {
      showToast(err.message || "Gagal mem-banned akun.");
    } finally {
      setBanBusy(false);
    }
  };

  const handleUnban = async (publicId) => {
    try {
      await db.unbanUser(publicId);
      showToast("Akun di-unban. ✅");
      await loadMembers();
    } catch (err) {
      showToast(err.message || "Gagal unban akun.");
    }
  };

  const handleToggleSeller = async (publicId, makeSeller) => {
    setSellerBusyId(publicId);
    try {
      await db.setSellerStatus(publicId, makeSeller);
      showToast(makeSeller ? "Akun dijadikan seller! 🏷️" : "Status seller dicabut.");
      await loadMembers();
    } catch (err) {
      showToast(err.message || "Gagal mengubah status seller.");
    } finally {
      setSellerBusyId(null);
    }
  };

  const handleToggleVerified = async (publicId, makeVerified) => {
    setVerifiedBusyId(publicId);
    try {
      await db.setVerifiedStatus(publicId, makeVerified);
      showToast(makeVerified ? "Centang biru diberikan! ✅" : "Centang biru dicabut.");
      await loadMembers();
    } catch (err) {
      showToast(err.message || "Gagal mengubah status centang biru.");
    } finally {
      setVerifiedBusyId(null);
    }
  };

  return (
    <div style={S.section}>
      <div style={{ paddingTop: 20, marginBottom: 16 }}>
        <div style={{ fontSize: 11, color: "#FF6B35", fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", marginBottom: 4 }}>⚡ Owner Panel</div>
        <div style={S.h1}>Kelola Toko</div>
      </div>

      {/* Tabs */}
      <div className="ds-hide-scrollbar" style={{ display: "flex", gap: 8, marginBottom: 20, overflowX: "auto" }}>
        {[
          { id: "products", label: `📦 Produk (${products.length})` },
          { id: "categories", label: `📂 Kategori (${categories.length})` },
          { id: "notify", label: "📣 Kirim Notifikasi" },
          { id: "members", label: "👥 Member" },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            background: tab === t.id ? "linear-gradient(135deg,#CC1818,#FF3B3B)" : "#12121E",
            color: tab === t.id ? "#fff" : "#aaa",
            border: tab === t.id ? "none" : "1px solid #1E1E30",
            borderRadius: 10, padding: "9px 18px", fontWeight: 700, fontSize: 13, cursor: "pointer", whiteSpace: "nowrap", flexShrink: 0
          }}>{t.label}</button>
        ))}
      </div>

      {tab === "products" && (
        <>
          {!showForm ? (
            <button style={{ ...S.btnPrimary, marginBottom: 16 }} onClick={() => { setEditProduct(null); setShowForm(true); }}>+ Tambah Produk Baru</button>
          ) : (
            <ProductForm
              initial={editProduct}
              categories={categories}
              saving={saving}
              onSave={async (prod) => {
                setSaving(true);
                try {
                  const isNewProduct = !editProduct;
                  // New product added directly by the owner = store product (seller_id null).
                  // Editing an existing product: omit the param so seller_id (whoever it
                  // already belongs to — store or a specific seller) is left untouched.
                  await (isNewProduct ? db.saveProduct(prod, null) : db.saveProduct(prod));
                  if (isNewProduct) {
                    const allIds = await db.getAllProfileIds();
                    if (allIds.length) {
                      await db.sendNotificationToMany(allIds, "new-product", `Produk baru: "${prod.name}" sudah tersedia!`, `/produk/${prod.id}`);
                    }
                  }
                  await refresh();
                  setShowForm(false);
                  setEditProduct(null);
                  showToast(editProduct ? "Produk diperbarui! ✅" : "Produk ditambahkan & notifikasi terkirim! 🐉");
                } catch (err) {
                  showToast(err.message || "Gagal menyimpan produk.");
                } finally {
                  setSaving(false);
                }
              }}
              onCancel={() => { setShowForm(false); setEditProduct(null); }}
            />
          )}

          {!showForm && products.map(p => (
            <div key={p.id} style={{ background: "#12121E", border: "1px solid #1E1E30", borderRadius: 14, padding: 14, marginBottom: 10, display: "flex", gap: 12, alignItems: "center" }}>
              <ImgBox src={p.images?.[0]} style={{ width: 60, height: 60, objectFit: "cover", borderRadius: 10, flexShrink: 0 }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: 14, color: "#F0F0FF", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{p.name}</div>
                <div style={{ fontSize: 11, color: "#FF6B35", marginTop: 2 }}>{p.category}</div>
                <div style={{ fontSize: 11, color: "#666", marginTop: 2, fontFamily: "monospace" }}>ID: {p.id}</div>
                {p.seller ? (
                  <div style={{ fontSize: 11, color: "#3B9CFF", marginTop: 2, fontWeight: 600 }}>🏷️ Seller: {p.seller.username}</div>
                ) : (
                  <div style={{ fontSize: 11, color: "#666", marginTop: 2 }}>🏠 Produk Toko</div>
                )}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6, flexShrink: 0 }}>
                <button style={S.btnSmall} onClick={() => { setEditProduct(p); setShowForm(true); }}>Edit</button>
                <button style={{ ...S.btnDanger, padding: "7px 12px", fontSize: 12 }} onClick={() => handleDeleteProduct(p.id)}>Hapus</button>
              </div>
            </div>
          ))}
        </>
      )}

      {tab === "categories" && (
        <>
          <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
            <input style={{ ...S.input, flex: 1 }} placeholder="Nama kategori baru..." value={newCat} onChange={e => setNewCat(e.target.value)} onKeyDown={e => e.key === "Enter" && handleAddCategory()} />
            <button style={{ ...S.btnPrimary, width: "auto", padding: "0 20px" }} onClick={handleAddCategory}>+</button>
          </div>
          {categories.map(c => (
            <div key={c} style={{ background: "#12121E", border: "1px solid #1E1E30", borderRadius: 12, padding: "12px 16px", marginBottom: 8, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: 14, fontWeight: 600 }}>{c}</span>
              <button style={{ ...S.btnDanger, padding: "6px 12px", fontSize: 12 }} onClick={() => handleDeleteCategory(c)}>Hapus</button>
            </div>
          ))}
        </>
      )}

      {tab === "notify" && (
        <div>
          <p style={{ fontSize: 13, color: "#888", marginBottom: 18 }}>Kirim notifikasi custom ke member toko. Pilih targetnya di bawah.</p>

          <div style={S.formGroup}>
            <label style={S.label}>Judul Notifikasi *</label>
            <input style={S.input} placeholder="Misal: Promo Spesial!" value={notifTitle} onChange={e => setNotifTitle(e.target.value)} />
          </div>
          <div style={S.formGroup}>
            <label style={S.label}>Deskripsi *</label>
            <textarea style={S.textarea} placeholder="Isi pesan notifikasi..." value={notifDesc} onChange={e => setNotifDesc(e.target.value)} />
          </div>

          <div style={S.formGroup}>
            <label style={S.label}>Kirim ke</label>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => setNotifTarget("global")} style={{
                flex: 1, padding: "11px 0", borderRadius: 10, fontWeight: 700, fontSize: 13, cursor: "pointer",
                background: notifTarget === "global" ? "linear-gradient(135deg,#CC1818,#FF3B3B)" : "#12121E",
                color: notifTarget === "global" ? "#fff" : "#aaa",
                border: notifTarget === "global" ? "none" : "1px solid #1E1E30",
              }}>🌍 Global (semua member)</button>
              <button onClick={() => setNotifTarget("selected")} style={{
                flex: 1, padding: "11px 0", borderRadius: 10, fontWeight: 700, fontSize: 13, cursor: "pointer",
                background: notifTarget === "selected" ? "linear-gradient(135deg,#CC1818,#FF3B3B)" : "#12121E",
                color: notifTarget === "selected" ? "#fff" : "#aaa",
                border: notifTarget === "selected" ? "none" : "1px solid #1E1E30",
              }}>🎯 Pilih Member</button>
            </div>
          </div>

          {notifTarget === "selected" && (
            <div style={S.formGroup}>
              <label style={S.label}>Public ID Member</label>
              <textarea
                style={{ ...S.textarea, minHeight: 70, fontFamily: "monospace" }}
                placeholder="000000001, 000000003, 000000007"
                value={notifIds}
                onChange={e => setNotifIds(e.target.value)}
              />
              <div style={{ fontSize: 11, color: "#666", marginTop: 6 }}>Pisahkan dengan koma atau baris baru. Public ID terlihat di halaman profil tiap member (/profile/xxxxxxxxx).</div>
            </div>
          )}

          <button style={{ ...S.btnPrimary, opacity: sendingNotif ? 0.6 : 1 }} disabled={sendingNotif} onClick={handleSendNotification}>
            {sendingNotif ? "Mengirim..." : "📣 Kirim Notifikasi"}
          </button>
        </div>
      )}

      {tab === "members" && (
        <div>
          {members === null ? <Spinner /> : members.length === 0 ? (
            <p style={{ color: "#555", fontSize: 13, textAlign: "center", padding: "20px 0" }}>Belum ada member terdaftar.</p>
          ) : (
            <>
              {/* Online/offline summary */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 18, maxWidth: 480 }}>
                <StatCard icon="👥" label="Total Member" value={members.length} color="#FF8C00" />
                <StatCard icon="🟢" label="Online" value={members.filter(m => db.isOnline(m.last_seen)).length} color="#2ECC71" />
                <StatCard icon="⚪" label="Offline" value={members.filter(m => !db.isOnline(m.last_seen)).length} color="#666" />
              </div>

              {members.map(m => {
                const isBanned = m.banned_until && new Date(m.banned_until) > new Date();
                const isPermanent = isBanned && new Date(m.banned_until).getFullYear() > 9000;
                const isThisFormOpen = banTargetId === m.public_id;
                const online = db.isOnline(m.last_seen);
                return (
                  <div key={m.id} style={{ background: "#12121E", border: `1px solid ${isBanned ? "#5A1A1A" : "#1E1E30"}`, borderRadius: 14, padding: 14, marginBottom: 10 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10 }}>
                      <div style={{ minWidth: 0 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
                          <span style={{ width: 8, height: 8, borderRadius: "50%", background: online ? "#2ECC71" : "#555", flexShrink: 0 }} />
                          <div style={{ fontWeight: 700, fontSize: 14, color: "#F0F0FF" }}>{m.username}</div>
                          {isVerified(m) && <VerifiedBadge size={14} />}
                        </div>
                        <div style={{ fontSize: 11, color: online ? "#2ECC71" : "#666", marginTop: 2, fontWeight: 600 }}>{online ? "Online" : "Offline"}</div>
                        <div style={{ fontSize: 12, color: "#888", marginTop: 4 }}>{m.email}</div>
                        <div style={{ fontSize: 11, color: "#666", marginTop: 2, fontFamily: "monospace" }}>/profile/{m.public_id}</div>
                        {isBanned && (
                          <div style={{ fontSize: 11, color: "#FF3B3B", marginTop: 6, fontWeight: 700 }}>
                            🚫 Banned {isPermanent ? "permanen" : `sampai ${new Date(m.banned_until).toLocaleDateString("id-ID", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}`}
                            {m.ban_reason && <div style={{ fontWeight: 400, color: "#AA6666", marginTop: 2 }}>"{m.ban_reason}"</div>}
                          </div>
                        )}
                      </div>
                      <div style={{ flexShrink: 0, display: "flex", flexDirection: "column", gap: 6, alignItems: "flex-end" }}>
                        {m.email === OWNER_EMAIL ? null : (
                          <>
                            {isBanned ? (
                              <button style={{ ...S.btnSmall, background: "#1A3D1A", borderColor: "#2D5A2D", color: "#7FD67F" }} onClick={() => handleUnban(m.public_id)}>Unban</button>
                            ) : (
                              <button style={{ ...S.btnDanger, padding: "7px 12px", fontSize: 12 }} onClick={() => setBanTargetId(isThisFormOpen ? null : m.public_id)}>{isThisFormOpen ? "Batal" : "Ban"}</button>
                            )}
                            <button
                              style={{
                                ...S.btnSmall, padding: "7px 12px", fontSize: 12,
                                opacity: sellerBusyId === m.public_id ? 0.6 : 1,
                                ...(m.role === "seller" ? {} : { background: "#0A1A2A", borderColor: "#103050", color: "#3B9CFF" }),
                              }}
                              disabled={sellerBusyId === m.public_id}
                              onClick={() => handleToggleSeller(m.public_id, m.role !== "seller")}
                            >
                              {sellerBusyId === m.public_id ? "..." : (m.role === "seller" ? "Cabut Seller" : "🏷️ Jadikan Seller")}
                            </button>
                            <button
                              style={{
                                ...S.btnSmall, padding: "7px 12px", fontSize: 12,
                                opacity: verifiedBusyId === m.public_id ? 0.6 : 1,
                                ...(m.verified ? {} : { background: "#0A1A2A", borderColor: "#103050", color: "#3B9CFF" }),
                              }}
                              disabled={verifiedBusyId === m.public_id}
                              onClick={() => handleToggleVerified(m.public_id, !m.verified)}
                            >
                              {verifiedBusyId === m.public_id ? "..." : (m.verified ? "Cabut Centang Biru" : "✅ Beri Centang Biru")}
                            </button>
                          </>
                        )}
                      </div>
                    </div>

                    {isThisFormOpen && (
                      <div style={{ marginTop: 12, paddingTop: 12, borderTop: "1px solid #1E1E30" }}>
                        <div style={S.formGroup}>
                          <label style={S.label}>Durasi Ban (jam) — kosongkan untuk permanen</label>
                          <input style={S.input} type="number" placeholder="24" value={banDuration} onChange={e => setBanDuration(e.target.value)} />
                        </div>
                        <div style={S.formGroup}>
                          <label style={S.label}>Alasan (opsional)</label>
                          <input style={S.input} placeholder="Misal: Spam komentar" value={banReason} onChange={e => setBanReason(e.target.value)} />
                        </div>
                        <button style={{ ...S.btnDanger, width: "100%", opacity: banBusy ? 0.6 : 1 }} disabled={banBusy} onClick={() => handleConfirmBan(m.public_id)}>
                          {banBusy ? "Memproses..." : "Konfirmasi Ban"}
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Seller Page ────────────────────────────────────────────────────────────────
// A cut-down version of the owner's product management screen, scoped to only
// the products this seller created. Even if someone tampered with the client
// and tried to load other sellers' products here, the database RLS policies
// (see supabase/schema.sql) would reject any attempt to edit/delete them — this
// page just mirrors that restriction in the UI so it's never even shown.
function SellerPage({ user, showToast, navigate }) {
  const [products, setProducts] = useState(null);
  const [categories, setCategories] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [saving, setSaving] = useState(false);

  const refresh = async () => {
    const [prods, cats] = await Promise.all([db.getProductsBySeller(user.id), db.getCategories()]);
    setProducts(prods);
    setCategories(cats);
  };

  useEffect(() => { refresh(); }, []);

  if (products === null) return <Spinner />;

  const handleDeleteProduct = async (id) => {
    try {
      await db.deleteProduct(id);
      setProducts(products.filter(p => p.id !== id));
      showToast("Produk dihapus.");
    } catch (err) {
      showToast(err.message || "Gagal menghapus produk.");
    }
  };

  return (
    <div style={S.section}>
      <div style={{ paddingTop: 20, marginBottom: 16 }}>
        <div style={{ fontSize: 11, color: "#3B9CFF", fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", marginBottom: 4 }}>🏷️ Seller Panel</div>
        <div style={S.h1}>Produk Jualan Saya</div>
        <p style={S.subtitle}>Kamu hanya bisa mengelola produk milikmu sendiri di sini.</p>
      </div>

      <div style={{ marginBottom: 20, maxWidth: 220 }}>
        <StatCard icon="📦" label="Produk Saya" value={products.length} color="#3B9CFF" />
      </div>

      {!showForm ? (
        <button style={{ ...S.btnPrimary, marginBottom: 16 }} onClick={() => { setEditProduct(null); setShowForm(true); }}>+ Tambah Produk Baru</button>
      ) : (
        <ProductForm
          initial={editProduct}
          categories={categories}
          saving={saving}
          onSave={async (prod) => {
            setSaving(true);
            try {
              // Sellers always pass their own id explicitly, on both create
              // AND edit, so it's unambiguous to the database which seller
              // this product belongs to (also required by the RLS check).
              await db.saveProduct(prod, user.id);
              await refresh();
              setShowForm(false);
              setEditProduct(null);
              showToast(editProduct ? "Produk diperbarui! ✅" : "Produk ditambahkan! 🐉");
            } catch (err) {
              showToast(err.message || "Gagal menyimpan produk.");
            } finally {
              setSaving(false);
            }
          }}
          onCancel={() => { setShowForm(false); setEditProduct(null); }}
        />
      )}

      {!showForm && (
        products.length === 0 ? (
          <div style={{ ...S.emptyState, padding: "40px 0" }}>
            <div style={{ fontSize: 50, marginBottom: 12 }}>🏷️</div>
            <p style={{ color: "#555" }}>Belum ada produk. Tambahkan produk pertamamu!</p>
          </div>
        ) : (
          products.map(p => (
            <div key={p.id} style={{ background: "#12121E", border: "1px solid #1E1E30", borderRadius: 14, padding: 14, marginBottom: 10, display: "flex", gap: 12, alignItems: "center" }}>
              <ImgBox src={p.images?.[0]} style={{ width: 60, height: 60, objectFit: "cover", borderRadius: 10, flexShrink: 0 }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: 14, color: "#F0F0FF", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{p.name}</div>
                <div style={{ fontSize: 11, color: "#FF6B35", marginTop: 2 }}>{p.category}</div>
                <div style={{ fontSize: 11, color: "#666", marginTop: 2, fontFamily: "monospace" }}>ID: {p.id}</div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6, flexShrink: 0 }}>
                <button style={S.btnSmall} onClick={() => { setEditProduct(p); setShowForm(true); }}>Edit</button>
                <button style={{ ...S.btnDanger, padding: "7px 12px", fontSize: 12 }} onClick={() => handleDeleteProduct(p.id)}>Hapus</button>
              </div>
            </div>
          ))
        )
      )}
    </div>
  );
}

// ─── Product Form ─────────────────────────────────────────────────────────────
function ProductForm({ initial, categories, onSave, onCancel, saving }) {
  const [form, setForm] = useState({
    id: initial?.id || genId(),
    name: initial?.name || "",
    category: initial?.category || categories[0] || "",
    description: initial?.description || "",
    phone: initial?.phone || "",
    images: initial?.images || [""],
  });

  const addImage = () => setForm({ ...form, images: [...form.images, ""] });
  const updateImage = (i, v) => { const imgs = [...form.images]; imgs[i] = v; setForm({ ...form, images: imgs }); };
  const removeImage = (i) => { const imgs = form.images.filter((_, idx) => idx !== i); setForm({ ...form, images: imgs.length ? imgs : [""] }); };

  const handleSave = () => {
    if (!form.name.trim()) { alert("Nama produk wajib diisi."); return; }
    const validImgs = form.images.filter(i => i.trim());
    if (!validImgs.length) { alert("Minimal satu gambar produk wajib diisi."); return; }
    onSave({ ...form, images: validImgs });
  };

  return (
    <div style={{ background: "#12121E", border: "1px solid #2E2E45", borderRadius: 16, padding: 18, marginBottom: 16 }}>
      <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 16, color: "#F0F0FF" }}>{initial ? "Edit Produk" : "Tambah Produk Baru"}</div>

      <div style={S.formGroup}>
        <label style={S.label}>Product ID <span style={{ color: "#666" }}>(otomatis)</span></label>
        <input style={{ ...S.input, color: "#FF6B35", fontFamily: "monospace", background: "#0F0F1A" }} value={form.id} readOnly />
      </div>

      <div style={S.formGroup}>
        <label style={S.label}>Nama Produk *</label>
        <input style={S.input} placeholder="Nama produk..." value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
      </div>

      <div style={S.formGroup}>
        <label style={S.label}>Kategori</label>
        <select style={S.select} value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
          {categories.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      <div style={S.formGroup}>
        <label style={S.label}>Deskripsi</label>
        <textarea style={S.textarea} placeholder="Deskripsi produk..." value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
      </div>

      <div style={S.formGroup}>
        <label style={S.label}>Nomor WhatsApp Penjual</label>
        <input style={S.input} placeholder="628123456789" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
        <div style={{ fontSize: 11, color: "#666", marginTop: 6 }}>Format: 628xxxxxxxxx (tanpa + atau 0 di depan)</div>
      </div>

      <div style={S.formGroup}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
          <label style={S.label}>Gambar Produk * (URL)</label>
          <button style={S.btnSmall} onClick={addImage}>+ Tambah</button>
        </div>
        {form.images.map((img, i) => (
          <div key={i} style={{ display: "flex", gap: 8, marginBottom: 8 }}>
            <input style={{ ...S.input, flex: 1 }} placeholder={`URL Gambar ${i + 1}...`} value={img} onChange={e => updateImage(i, e.target.value)} />
            {form.images.length > 1 && <button style={{ ...S.btnDanger, flexShrink: 0 }} onClick={() => removeImage(i)}>✕</button>}
          </div>
        ))}
        <div style={{ fontSize: 11, color: "#666" }}>Masukkan URL gambar langsung (contoh: https://i.imgur.com/xxx.jpg)</div>
      </div>

      <div style={{ display: "flex", gap: 10 }}>
        <button style={{ ...S.btnPrimary, flex: 1, opacity: saving ? 0.6 : 1 }} disabled={saving} onClick={handleSave}>{saving ? "Menyimpan..." : (initial ? "Simpan Perubahan" : "Tambah Produk 🐉")}</button>
        <button style={{ ...S.btnSecondary, flex: 1 }} onClick={onCancel}>Batal</button>
      </div>
    </div>
  );
}
