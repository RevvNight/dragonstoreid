import { supabase, secureAuth } from './supabaseClient';

export const OWNER_EMAIL = "iputu.aditya789@gmail.com";

// ── Auth ─────────────────────────────────────────────────────────────────────
// signUp lewat Netlify Function (server-side) supaya service role key aman.
// Rate limit dan validasi juga ditangani di server.
export async function signUp(username, email, password) {
  const redirectTo = `${window.location.origin}/verify`;
  return await secureAuth('signup', { username, email, password, redirectTo });
}

// Resend email verifikasi
export async function resendVerificationEmail(email) {
  const redirectTo = `${window.location.origin}/verify`;
  return await secureAuth('resend_verification', { email, redirectTo });
}

export async function signIn(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data;
}

export async function signOut() {
  await supabase.auth.signOut();
}

export async function getCurrentSession() {
  const { data } = await supabase.auth.getSession();
  return data.session;
}

// Returns the profile row (username, public_id, etc) for the logged-in user, or null.
export async function getMyProfile() {
  const { data: sessionData } = await supabase.auth.getUser();
  const authUser = sessionData?.user;
  if (!authUser) return null;
  const { data, error } = await supabase.from('profiles').select('*').eq('id', authUser.id).single();
  if (error) return null;
  return data;
}

export async function updateMyProfile(id, fields) {
  const { error } = await supabase.from('profiles').update(fields).eq('id', id);
  if (error) throw error;
}

export async function changePassword(newPassword) {
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  if (error) throw error;
}

// ── Profiles (public) ─────────────────────────────────────────────────────────
export async function getProfileByPublicId(publicId) {
  const { data, error } = await supabase.from('profiles').select('*').eq('public_id', publicId).single();
  if (error) return null;
  return data;
}

// ── Categories ───────────────────────────────────────────────────────────────
export async function getCategories() {
  const { data, error } = await supabase.from('categories').select('name').order('created_at');
  if (error) return [];
  return data.map(c => c.name);
}

export async function addCategory(name) {
  const { error } = await supabase.from('categories').insert({ name });
  if (error) throw error;
}

export async function deleteCategory(name) {
  const { error } = await supabase.from('categories').delete().eq('name', name);
  if (error) throw error;
}

// ── Products ─────────────────────────────────────────────────────────────────
function genId() {
  return Math.random().toString(36).substr(2, 9).toUpperCase();
}

export async function getProducts() {
  const { data, error } = await supabase.from('products').select('*').order('created_at', { ascending: false });
  if (error) return [];
  return data.map(p => ({ ...p, phone: p.phone || "" }));
}

// Like getProducts(), but also embeds the seller's username/public_id (when
// the product belongs to a seller) — used in the owner panel so the owner can
// see at a glance who added each product.
export async function getProductsWithSellerInfo() {
  const { data, error } = await supabase
    .from('products')
    .select('*, seller:seller_id(username, public_id)')
    .order('created_at', { ascending: false });
  if (error) return [];
  return data.map(p => ({ ...p, phone: p.phone || "" }));
}

// Products created by a specific seller (used by the seller's own management panel).
export async function getProductsBySeller(sellerId) {
  if (!sellerId) return [];
  const { data, error } = await supabase.from('products').select('*').eq('seller_id', sellerId).order('created_at', { ascending: false });
  if (error) return [];
  return data.map(p => ({ ...p, phone: p.phone || "" }));
}

export async function getProductById(id) {
  const { data, error } = await supabase.from('products').select('*').eq('id', id).single();
  if (error) return null;
  return data;
}

// sellerId is explicit and optional:
//   - omit it entirely (undefined) → the seller_id column is left untouched:
//     stays NULL on a fresh insert (store/owner product), or keeps whatever
//     it already was when editing an existing product (so the owner editing
//     a seller's product never accidentally wipes out who it belongs to).
//   - pass a value (a seller's profile id, or null) → seller_id is set to
//     exactly that. Sellers should always pass their own id here, on both
//     create AND edit, so it's unambiguous to the RLS check.
export async function saveProduct(product, sellerId) {
  const id = product.id || genId();
  const row = {
    id,
    name: product.name,
    category: product.category,
    description: product.description,
    phone: product.phone,
    images: product.images,
  };
  if (sellerId !== undefined) {
    row.seller_id = sellerId;
  }
  const { error } = await supabase.from('products').upsert(row);
  if (error) throw error;
  return id;
}

export async function deleteProduct(id) {
  const { error } = await supabase.from('products').delete().eq('id', id);
  if (error) throw error;
}

// ── Product interactions: likes / favorites / saves ──────────────────────────
const interactionTable = { likes: 'product_likes', favorites: 'product_favorites', saves: 'product_saves' };

export async function getInteractionCount(kind, productId) {
  const { count, error } = await supabase
    .from(interactionTable[kind])
    .select('*', { count: 'exact', head: true })
    .eq('product_id', productId);
  if (error) return 0;
  return count || 0;
}

// Fetch counts for many products in one call (avoids N+1 queries on list pages).
export async function getInteractionCountsBulk(kind, productIds) {
  if (!productIds.length) return {};
  const { data, error } = await supabase
    .from(interactionTable[kind])
    .select('product_id')
    .in('product_id', productIds);
  if (error) return {};
  const counts = {};
  data.forEach(row => { counts[row.product_id] = (counts[row.product_id] || 0) + 1; });
  return counts;
}

export async function isInteracted(kind, productId, userId) {
  if (!userId) return false;
  const { data, error } = await supabase
    .from(interactionTable[kind])
    .select('product_id')
    .eq('product_id', productId)
    .eq('user_id', userId)
    .maybeSingle();
  if (error) return false;
  return !!data;
}

export async function toggleInteraction(kind, productId, userId) {
  const table = interactionTable[kind];
  const already = await isInteracted(kind, productId, userId);
  if (already) {
    await supabase.from(table).delete().eq('product_id', productId).eq('user_id', userId);
    return false;
  } else {
    await supabase.from(table).insert({ product_id: productId, user_id: userId });
    return true;
  }
}

// Products a given user has liked/favorited/saved, joined with product rows.
export async function getMyInteractedProducts(kind, userId) {
  if (!userId) return [];
  const { data, error } = await supabase
    .from(interactionTable[kind])
    .select('product_id, products(*)')
    .eq('user_id', userId);
  if (error) return [];
  return data.map(row => row.products).filter(Boolean);
}

// ── Profile likes ──────────────────────────────────────────────────────────
export async function getProfileLikeCount(profileId) {
  const { count, error } = await supabase
    .from('profile_likes')
    .select('*', { count: 'exact', head: true })
    .eq('profile_id', profileId);
  if (error) return 0;
  return count || 0;
}

export async function isProfileLiked(profileId, likerId) {
  if (!likerId) return false;
  const { data, error } = await supabase
    .from('profile_likes')
    .select('profile_id')
    .eq('profile_id', profileId)
    .eq('liker_id', likerId)
    .maybeSingle();
  if (error) return false;
  return !!data;
}

export async function toggleProfileLike(profileId, likerId) {
  const already = await isProfileLiked(profileId, likerId);
  if (already) {
    await supabase.from('profile_likes').delete().eq('profile_id', profileId).eq('liker_id', likerId);
    return false;
  } else {
    await supabase.from('profile_likes').insert({ profile_id: profileId, liker_id: likerId });
    return true;
  }
}

// ── Comments ─────────────────────────────────────────────────────────────────
export async function getComments(productId) {
  const { data, error } = await supabase
    .from('comments')
    .select('id, text, created_at, user_id, profiles(username, public_id, role, verified), comment_likes(user_id)')
    .eq('product_id', productId)
    .order('created_at', { ascending: false });
  if (error) return [];
  return data.map(c => ({
    id: c.id,
    text: c.text,
    createdAt: new Date(c.created_at).getTime(),
    userId: c.user_id,
    username: c.profiles?.username || "Pengguna",
    userPublicId: c.profiles?.public_id || null,
    userRole: c.profiles?.role || "member",
    userVerified: c.profiles?.verified || false,
    likedBy: (c.comment_likes || []).map(l => l.user_id),
  }));
}

export async function postComment(productId, userId, text) {
  const { error } = await supabase.from('comments').insert({ product_id: productId, user_id: userId, text });
  if (error) throw error;
}

export async function deleteComment(commentId) {
  const { error } = await supabase.from('comments').delete().eq('id', commentId);
  if (error) throw error;
}

export async function toggleCommentLike(commentId, userId) {
  const { data } = await supabase.from('comment_likes').select('comment_id').eq('comment_id', commentId).eq('user_id', userId).maybeSingle();
  if (data) {
    await supabase.from('comment_likes').delete().eq('comment_id', commentId).eq('user_id', userId);
    return false;
  } else {
    await supabase.from('comment_likes').insert({ comment_id: commentId, user_id: userId });
    return true;
  }
}

// ── Notifications ─────────────────────────────────────────────────────────────
export async function addNotification(userId, type, message, link) {
  if (!userId) return;
  await supabase.from('notifications').insert({ user_id: userId, type, message, link });
}

export async function getMyNotifications(userId) {
  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) return [];
  return data.map(n => ({ ...n, createdAt: new Date(n.created_at).getTime() }));
}

export async function markAllNotificationsRead(userId) {
  await supabase.from('notifications').update({ read: true }).eq('user_id', userId).eq('read', false);
}

export async function getUnreadNotificationCount(userId) {
  if (!userId) return 0;
  const { count, error } = await supabase
    .from('notifications')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('read', false);
  if (error) return 0;
  return count || 0;
}

// Find the owner's profile row (for routing notifications to them).
export async function getOwnerProfile() {
  const { data, error } = await supabase.from('profiles').select('*').eq('email', OWNER_EMAIL).maybeSingle();
  if (error) return null;
  return data;
}

// ── Ban system ─────────────────────────────────────────────────────────────────
export const OWNER_PHONE = "6282172549108"; // wa.me format: country code, no leading 0

// Checks the current user's ban status. If the ban has expired, this also
// triggers permanent account deletion via the security-definer RPC, then signs out.
// Returns: { banned: false } | { banned: true, until: Date, reason: string }
export async function checkMyBanStatus() {
  const profile = await getMyProfile();
  if (!profile || !profile.banned_until) return { banned: false };
  const until = new Date(profile.banned_until);
  if (until <= new Date()) {
    // Ban has expired — delete the account permanently, then sign out.
    try { await supabase.rpc('delete_my_account_if_ban_expired'); } catch { /* best effort */ }
    await supabase.auth.signOut();
    return { banned: false, justDeleted: true };
  }
  return { banned: true, until, reason: profile.ban_reason || "" };
}

export async function banUser(targetPublicId, durationHours, reason) {
  const { error } = await supabase.rpc('ban_user', {
    target_public_id: targetPublicId,
    duration_hours: durationHours, // null = permanent
    reason: reason || null,
  });
  if (error) throw error;
}

export async function unbanUser(targetPublicId) {
  const { error } = await supabase.rpc('unban_user', { target_public_id: targetPublicId });
  if (error) throw error;
}

export async function getAllProfilesWithBanStatus() {
  const { data, error } = await supabase.from('profiles').select('id, username, email, public_id, role, verified, banned_until, ban_reason, last_seen').order('created_at', { ascending: false });
  if (error) return [];
  return data;
}

// ── Seller management (owner only) ───────────────────────────────────────────
// Promotes/demotes a member via a security-definer RPC (the app UI only exposes
// this to the owner account; the RPC itself also re-checks that the caller is
// the owner before doing anything, so it can't be abused even via direct API calls).
export async function setSellerStatus(targetPublicId, makeSeller) {
  const { error } = await supabase.rpc('set_seller_status', {
    target_public_id: targetPublicId,
    make_seller: makeSeller,
  });
  if (error) throw error;
}

// ── Verified badge management (owner only) ───────────────────────────────────
// Independent of role: a seller isn't automatically verified, and a plain
// member could be verified if the owner chooses to. The owner's own account
// is always treated as verified automatically (see isVerified() in App.jsx),
// so this toggle is only meaningful for non-owner accounts.
export async function setVerifiedStatus(targetPublicId, makeVerified) {
  const { error } = await supabase.rpc('set_verified_status', {
    target_public_id: targetPublicId,
    make_verified: makeVerified,
  });
  if (error) throw error;
}

// ── Online/offline presence ────────────────────────────────────────────────────
// A user counts as "online" if last_seen is within this window. The app calls
// touchLastSeen() periodically (heartbeat) while it's open in the foreground.
export const ONLINE_THRESHOLD_MS = 2 * 60 * 1000; // 2 minutes

export async function touchLastSeen(userId) {
  if (!userId) return;
  await supabase.from('profiles').update({ last_seen: new Date().toISOString() }).eq('id', userId);
}

export function isOnline(lastSeen) {
  if (!lastSeen) return false;
  return Date.now() - new Date(lastSeen).getTime() < ONLINE_THRESHOLD_MS;
}

export async function getProfileLastSeen(profileId) {
  const { data, error } = await supabase.from('profiles').select('last_seen').eq('id', profileId).single();
  if (error) return null;
  return data.last_seen;
}
export async function getAllProfileIds() {
  const { data, error } = await supabase.from('profiles').select('id');
  if (error) return [];
  return data.map(p => p.id);
}

export async function getProfilesByPublicIds(publicIds) {
  const { data, error } = await supabase.from('profiles').select('id, public_id, username').in('public_id', publicIds);
  if (error) return [];
  return data;
}

// Sends the same notification to every row in userIds. Supabase doesn't have a
// single "insert for everyone" call, so we build one row per recipient and bulk-insert.
export async function sendNotificationToMany(userIds, type, message, link) {
  if (!userIds.length) return;
  const rows = userIds.map(userId => ({ user_id: userId, type, message, link }));
  const { error } = await supabase.from('notifications').insert(rows);
  if (error) throw error;
}

// ── Friends ──────────────────────────────────────────────────────────────────
// One-directional model: when A adds B, it just means A considers B a friend
// (like "following"). Friend COUNT is public (via the get_friend_count RPC,
// which runs as security definer so it can count rows the caller themselves
// isn't allowed to read individually), but the LIST of who's on your list stays
// private — RLS only lets you read your own rows.

// Search users by username (for the "find friends" search box). Excludes the
// current user from results so you can't add yourself.
export async function searchProfiles(query, excludeUserId) {
  if (!query || !query.trim()) return [];
  let q = supabase.from('profiles').select('id, username, public_id, role, verified').ilike('username', `%${query.trim()}%`).limit(20);
  if (excludeUserId) q = q.neq('id', excludeUserId);
  const { data, error } = await q;
  if (error) return [];
  return data;
}

// Your own friend list (private to you — used only to know which search
// results already have a "✓ Berteman" vs "+ Tambah Teman" button state).
export async function getMyFriendIds(userId) {
  if (!userId) return [];
  const { data, error } = await supabase.from('friends').select('friend_id').eq('user_id', userId);
  if (error) return [];
  return data.map(r => r.friend_id);
}

export async function addFriend(userId, friendId) {
  const { error } = await supabase.from('friends').insert({ user_id: userId, friend_id: friendId });
  if (error) throw error;
}

export async function removeFriend(userId, friendId) {
  const { error } = await supabase.from('friends').delete().eq('user_id', userId).eq('friend_id', friendId);
  if (error) throw error;
}

// Public friend count for any profile (shown on profile pages). The identity
// of those friends is never exposed by this call.
export async function getFriendCount(userId) {
  const { data, error } = await supabase.rpc('get_friend_count', { target_user_id: userId });
  if (error) return 0;
  return data || 0;
}

// Notifies everyone who has `likerId` as a friend that they liked a product.
// Server-side RPC, because the liker themselves can't read who follows them.
export async function notifyFriendsOfProductLike(likerId, productId, productName) {
  const { error } = await supabase.rpc('notify_friends_of_product_like', {
    p_liker_id: likerId,
    p_product_id: productId,
    p_product_name: productName,
  });
  if (error) throw error;
}
